package Client;


import nm2.Reader;
import nm2.Writer;
import util.networkutil;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class ClientMain1 implements Runnable{
    
        public ClientMain1(){
           new Thread(this).start();
         
        }
        
    /*    public static void main(String[] args) {
            new ClientMain();
            
        }*/

    @Override
    public void run() {
         networkutil nc=new networkutil("127.0.0.1", 44444);
           
             new Thread(new Reader(nc)).start();
               new Thread(new Writer(nc)).start();
          
                
    }
}
