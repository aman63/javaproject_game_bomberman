package Client;


import java.util.logging.Level;
import java.util.logging.Logger;
import nm.Reader;
import nm.Writer;

import util.networkutil;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class ClientMain implements Runnable{
    
        public ClientMain(){
           new Thread(this).start();
         
        }
        
    /*    public static void main(String[] args) {
            new ClientMain();
            
        }*/

    @Override
    public void run() {
         networkutil nc=new networkutil("127.0.0.1", 44444);
            try {
                Thread.sleep(500);
            } catch (InterruptedException ex) {
                Logger.getLogger(ClientMain.class.getName()).log(Level.SEVERE, null, ex);
            }
             new Thread(new Reader(nc)).start();
               new Thread(new Writer(nc)).start();
      
                 
           
    }
}
