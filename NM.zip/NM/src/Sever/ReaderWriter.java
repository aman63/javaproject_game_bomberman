/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sever;

import util.data;
import util.networkutil;

/**
 *
 * @author User
 */
public class ReaderWriter implements Runnable{
        public networkutil thisClient;
        public networkutil otherClient;
        
        public ReaderWriter(networkutil client1,networkutil client2){
            thisClient=client1;
            otherClient=client2;
            
        }

    @Override
    public void run() {
       while(true){
            Object o=thisClient.read();
            otherClient.write(o);
       }
    }
    
}
