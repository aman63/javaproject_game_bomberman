/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sever;


import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;
import javafx.animation.AnimationTimer;
import javafx.scene.paint.Color;

import util.networkutil;

/**
 *
 * @author User
 */

public class ServerMain {
    
    public ServerSocket serverSocket;
   
    
    public ServerMain(){
         
        
       
        try {
            serverSocket=new ServerSocket(44444);
          
            System.out.println("Waiting for client 1");
            Socket clientSocket1=serverSocket.accept();
            System.out.println("Client 1 Connected");
            
            System.out.println("Waiting for client 2");
            Socket clientSocket2=serverSocket.accept();
            System.out.println("Client 2 Connected");
            
            
            networkutil c1=new networkutil(clientSocket1);
            networkutil c2=new networkutil(clientSocket2);
           
            new Thread(new ReaderWriter(c1, c2)).start();
            new Thread(new ReaderWriter(c2, c1)).start();
      
            
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        
        
        
    }
    
    public static void main(String[] args) {
        new ServerMain();
        
    }
    
    
}
