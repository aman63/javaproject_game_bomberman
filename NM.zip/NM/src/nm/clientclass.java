/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nm;


import myutil.networkutil;
import java.io.IOException;
import java.net.Socket;
import myutil.data;

/**
 *
 * @author User
 */
public class clientclass implements Runnable{
    networkutil nc;
    clientclass(){
        try{
        nc=new networkutil("127.0.0.1",44444);
        }catch(Exception e){
            System.out.println("can not connect to server");
        }
        new Thread(this).start();
    }
    @Override
    public void run() {
        data d;
        boolean flag=true;
        while(true){
            if(!flag) break;
            try{
            d=new data(NM.image.getX(),NM.image.getY());
            nc.write(d);
            Thread.sleep(1000);
            }catch(Exception e){
                System.out.println("connection from server is lost");
               flag=false;
        }
    }
    }
}
