/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nm;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author User
 */
public class thread_f implements Runnable{
    
  public thread_f(){
        new Thread(this).start();
    }
  
    public void run() {
        if(NM.number_of_lives_left==5){
            NM.life5.setX(2000);
            NM.life5.setX(2000);
             NM.number_of_lives_left--;
            
            
        }else if(NM.number_of_lives_left==4){
            NM.life4.setX(2000);
            NM.life4.setY(2000);
             NM.number_of_lives_left--;
             
        }else if(NM.number_of_lives_left==3){
            NM.life3.setX(2000);
            NM.life3.setY(2000);
             NM.number_of_lives_left--;
            
        }else if(NM.number_of_lives_left==2){
            NM.life2.setX(2000);
            NM.life2.setY(2000);
             NM.number_of_lives_left--;
             
        }else if(NM.number_of_lives_left==1){
            NM.life1.setX(2000);
            NM.life1.setY(2000);
             NM.number_of_lives_left--;
             NM.gameover.setX(0);
             NM.gameover.setY(0);
            try {
                Thread.sleep(300);
                System.exit(0);
            } catch (InterruptedException ex) {
                Logger.getLogger(thread_f.class.getName()).log(Level.SEVERE, null, ex);
            }
          
        }try{
            
            Thread.sleep(500);
             NM.flag=true;
           
        }catch(Exception e){
            
            
            System.out.println("got it");
        }
    }
    
}

