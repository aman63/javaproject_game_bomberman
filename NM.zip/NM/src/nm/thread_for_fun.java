/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nm;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.AnimationTimer;
import javafx.scene.paint.Color;

/**
 *
 * @author User
 */
public class thread_for_fun implements Runnable{
      double  last;
    double  count=0;
    colon Colon[];
    public thread_for_fun(){
     Colon=new colon[5]; 
      Random rand=new Random();
        for(int i=0;i<Colon.length;i++){
              Colon[i]=new colon(Math.random()*600,Math.random()*600, Math.random()*5,Math.random()*5,i+1);
      
        //    Colon[i]=new colon(Math.random()*600,Math.random()*600, Math.random()*5,Math.random()*5,i+1);
        }
       
    }
      public void updateValue(){
           for(colon b:Colon){
             b.updateCenter(1);
              b.collision();
        }
     //   double time=(now-last)/1000000000.0;
        
 /*   for(int i=0;i<3;i++){
        NM.balls[i].updateCenter(1);
        NM.balls[i].collision();
    }*/
 
        
      //  ball.updateCenter(1);
      //  ball.collision();
        
        
        count++;
        
       // last=now;
    }
    @Override
    public void run() {
          try {
              Thread.sleep(1000);
          } catch (InterruptedException ex) {
              Logger.getLogger(thread_for_fun.class.getName()).log(Level.SEVERE, null, ex);
          }
        while(true){
    
            try {
               
                 updateValue();
                 Thread.sleep(100);
            } catch (InterruptedException ex) {
                Logger.getLogger(thread_for_fun.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
   /* public void runit(){
          //  new AnimationTimer() {

          //  @Override
          //  public void handle(long now) {
                updateValue();
           // }
       // }.start();
    }*/
    
    
    
}
