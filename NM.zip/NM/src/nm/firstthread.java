package nm;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.logging.Level;
import java.util.logging.Logger;
import nm.NM;
import static nm.NM.a;
import static nm.NM.b;
import static nm.NM.c;
import static nm.NM.d;



/**
 *
 * @author User
 */
public class firstthread implements Runnable{
    
    
    
   public void action(){
       
   }
    @Override
    public void run(){ 
       
        
        try{
          
            Thread.sleep(5000);
 
        }catch(Exception e){
            System.out.println("interrupted");
        }
       double x=NM.iMage.getX();
       double y=NM.iMage.getY();
        
       if((x>580&&x<=600)&&(y<=600&&y>580)){
        
       a=NM.iMage.getX()-200;//for bomb fourthbomb
       b=NM.iMage.getY();
       c=NM.iMage.getX()+10;//for bomb
       d=NM.iMage.getY()-157;
        NM.iMage.setX(NM.initialbomb1x);
        NM.iMage.setY(NM.initialbomb1y);

         NM.fireimage1.setX(a);
         NM.fireimage1.setY(b);
         NM.ullomboimage.setX(c);
         NM.ullomboimage.setY(d);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                    System.out.println("hh");
                } else if(Reader.flag&&(NM.fireimage1.getX()+changefirex1<=thismanx1)&&(NM.fireimage1.getX()+changefirex2>=thismanx2)&&(NM.fireimage1.getY()+changefirey1<=thismany1)&&(NM.fireimage1.getY()+changefirey2>=thismany2)){
                    
                   
                   Reader.flag=false;
                    new collidethread();
                  
                } 
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
        a=NM.initialfirex;
        b=NM.initialfirex;
        c=NM.initialfirex;
        d=NM.initialfirex;
           NM.fireimage1.setX(a);
       NM.fireimage1.setY(b);
         NM.ullomboimage.setX(c);
       NM.ullomboimage.setY(d);
          NM.is_bomb_set_first_bomb=0;
 
       }else if((x>=0&&x<40)&&(y<=600&&y>580)){
         a=NM.iMage.getX();//for bomb
       b=NM.iMage.getY();
         c=NM.iMage.getX();//for bomb
       d=NM.iMage.getY()-157;
       NM.iMage.setX(NM.initialbomb1x);
        NM.iMage.setY(NM.initialbomb1y);

         NM.fireimage1.setX(a);
         NM.fireimage1.setY(b);
         NM.ullomboimage.setX(c);
         NM.ullomboimage.setY(d);
           double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                    System.out.println("hh");
                } else if(Reader.flag&&(NM.fireimage1.getX()+changefirex1<=thismanx1)&&(NM.fireimage1.getX()+changefirex2>=thismanx2)&&(NM.fireimage1.getY()+changefirey1<=thismany1)&&(NM.fireimage1.getY()+changefirey2>=thismany2)){
                    
               Reader.flag=false;
                    new collidethread();
                  
                } 
                
      //}
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
          a=NM.initialfirex;
        b=NM.initialfirex;
        c=NM.initialfirex;
        d=NM.initialfirex;
           NM.fireimage1.setX(a);
       NM.fireimage1.setY(b);
         NM.ullomboimage.setX(c);
       NM.ullomboimage.setY(d);
          NM.is_bomb_set_first_bomb=0;
    
    }else if((y==600||(y>420&&y<470)||(y>270&&y<330)||(y>=130&&y<=170)||(y>=0&&y<=20))&&((x>=40&&x<=130)||(x>=190&&x<=280)||(x>=340&&x<=430)||(x>=490&&x<=580))){
       a=NM.iMage.getX()-100;//for first bomb
       b=NM.iMage.getY();
       NM.iMage.setX(NM.initialbomb1x);
        NM.iMage.setY(NM.initialbomb1y);

        NM.fireimage1.setX(a);
        NM.fireimage1.setY(b);
         
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
               
                if(Reader.flag&&(NM.fireimage1.getX()+changefirex1<=thismanx1)&&(NM.fireimage1.getX()+changefirex2>=thismanx2)&&(NM.fireimage1.getY()+changefirey1<=thismany1)&&(NM.fireimage1.getY()+changefirey2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                  
                } 
                
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
        a=NM.initialfirex;
        b=NM.initialfirey;
        NM.fireimage1.setX(a);
        NM.fireimage1.setY(b);
     
       NM.is_bomb_set_first_bomb=0;
   }else if((y==600)&&((x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490))){
       a=NM.iMage.getX()-100;// 3rd bomb
       b=NM.iMage.getY();
       c=NM.iMage.getX();//for bomb
       d=NM.iMage.getY()-157;
         NM.iMage.setX(NM.initialbomb1x);
        NM.iMage.setY(NM.initialbomb1y);
         NM.fireimage1.setX(a);
         NM.fireimage1.setY(b);
         NM.ullomboimage.setX(c);
         NM.ullomboimage.setY(d);
           double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                    System.out.println("hh");
                } else if(Reader.flag&&(NM.fireimage1.getX()+changefirex1<=thismanx1)&&(NM.fireimage1.getX()+changefirex2>=thismanx2)&&(NM.fireimage1.getY()+changefirey1<=thismany1)&&(NM.fireimage1.getY()+changefirey2>=thismany2)){
                    
                   
                 Reader.flag=false;
                    new collidethread();
                  
                } 
                
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
           a=NM.initialfirex;
        b=NM.initialfirex;
        c=NM.initialfirex;
        d=NM.initialfirex;
           NM.fireimage1.setX(a);
       NM.fireimage1.setY(b);
         NM.ullomboimage.setX(c);
       NM.ullomboimage.setY(d);
     
          NM.is_bomb_set_first_bomb=0;
   }else if(((y>=470&&y<=580)||(y>=330&&y<=420)||(y>=180&&y<=270)||(y>=30&&y<=120))&&((x>0&&x<40)||(x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490)||(x>580&&x<=600))){//commonfifth
       c=NM.iMage.getX()+10;//for fifth bomb
       d=NM.iMage.getY()-70;
       NM.iMage.setX(NM.initialbomb1x);
        NM.iMage.setY(NM.initialbomb1y);
        NM.ullomboimage.setX(c);
        NM.ullomboimage.setY(d);
          double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
               
                if(Reader.flag&&(NM.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                } 
                
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
        c=NM.initialfirex;
        d=NM.initialfirey;
        NM.ullomboimage.setX(c);
       NM.ullomboimage.setY(d);
       NM.is_bomb_set_first_bomb=0;
   }else if(((y<470&&y>420)||(y>270&&y<330)||(y>=130&&y<=170))&&(x>=0&&x<40)){
       a=NM.iMage.getX();//for sixth bomb
       b=NM.iMage.getY()-10;
         c=NM.iMage.getX()+10;//for bomb
       d=NM.iMage.getY()-70;
         NM.iMage.setX(NM.initialbomb1x);
        NM.iMage.setY(NM.initialbomb1y);
         NM.fireimage1.setX(a);
         NM.fireimage1.setY(b);
         NM.ullomboimage.setX(c);
         NM.ullomboimage.setY(d);
           double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage.getY()+changeullomboy2>=thismany2)){
                 
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM.fireimage1.getX()+changefirex1<=thismanx1)&&(NM.fireimage1.getX()+changefirex2>=thismanx2)&&(NM.fireimage1.getY()+changefirey1<=thismany1)&&(NM.fireimage1.getY()+changefirey2>=thismany2)){
                    Reader.flag=false;
                    new collidethread();
                  
                } 
                
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
           a=NM.initialfirex;
        b=NM.initialfirex;
        c=NM.initialfirex;
        d=NM.initialfirex;
           NM.fireimage1.setX(a);
       NM.fireimage1.setY(b);
         NM.ullomboimage.setX(c);
       NM.ullomboimage.setY(d);
   
          NM.is_bomb_set_first_bomb=0;
   }
       else if(((y>420&&y<470)||(y>270&&y<330)||(y>=130&&y<=170))&&(x>580&&x<=600)){
       a=NM.iMage.getX()-200;// 3rd bomb
       b=NM.iMage.getY();
         c=NM.iMage.getX()+10;//for bomb
       d=NM.iMage.getY()-79;
         NM.iMage.setX(NM.initialbomb1x);
        NM.iMage.setY(NM.initialbomb1y);
         NM.fireimage1.setX(a);
         NM.fireimage1.setY(b);
         NM.ullomboimage.setX(c);
         NM.ullomboimage.setY(d);
           double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage.getY()+changeullomboy2>=thismany2)){
                 
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM.fireimage1.getX()+changefirex1<=thismanx1)&&(NM.fireimage1.getX()+changefirex2>=thismanx2)&&(NM.fireimage1.getY()+changefirey1<=thismany1)&&(NM.fireimage1.getY()+changefirey2>=thismany2)){
                    
                  Reader.flag=false;
                    new collidethread();
                  
                } 
                
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
    
          a=NM.initialfirex;
        b=NM.initialfirex;
        c=NM.initialfirex;
        d=NM.initialfirex;
           NM.fireimage1.setX(a);
       NM.fireimage1.setY(b);
         NM.ullomboimage.setX(c);
       NM.ullomboimage.setY(d);
          NM.is_bomb_set_first_bomb=0;
   }else if(((y>420&&y<470)||(y>270&&y<330)||(y>=130&&y<=170))&&((x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490))){
       a=NM.iMage.getX()-100;// 3rd bomb
       b=NM.iMage.getY();
         c=NM.iMage.getX()+10;//for bomb
       d=NM.iMage.getY()-79;
         NM.iMage.setX(NM.initialbomb1x);
        NM.iMage.setY(NM.initialbomb1y);
         NM.fireimage1.setX(a);
         NM.fireimage1.setY(b);
         NM.ullomboimage.setX(c);
         NM.ullomboimage.setY(d);
           double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM.fireimage1.getX()+changefirex1<=thismanx1)&&(NM.fireimage1.getX()+changefirex2>=thismanx2)&&(NM.fireimage1.getY()+changefirey1<=thismany1)&&(NM.fireimage1.getY()+changefirey2>=thismany2)){
                    
                  Reader.flag=false;
                    new collidethread();
                } 
                
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
      
         a=NM.initialfirex;
        b=NM.initialfirex;
        c=NM.initialfirex;
        d=NM.initialfirex;
           NM.fireimage1.setX(a);
       NM.fireimage1.setY(b);
         NM.ullomboimage.setX(c);
       NM.ullomboimage.setY(d);

          NM.is_bomb_set_first_bomb=0;
   }else if((y>=0&&y<=20)&&((x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490))){
       a=NM.iMage.getX()-100;// 3rd bomb
       b=NM.iMage.getY();
         c=NM.iMage.getX();//for bomb
       d=NM.iMage.getY();
         NM.iMage.setX(NM.initialbomb1x);
        NM.iMage.setY(NM.initialbomb1y);
         NM.fireimage1.setX(a);
         NM.fireimage1.setY(b);
         NM.ullomboimage.setX(c);
         NM.ullomboimage.setY(d);
           double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage.getY()+changeullomboy2>=thismany2)){
                  Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM.fireimage1.getX()+changefirex1<=thismanx1)&&(NM.fireimage1.getX()+changefirex2>=thismanx2)&&(NM.fireimage1.getY()+changefirey1<=thismany1)&&(NM.fireimage1.getY()+changefirey2>=thismany2)){
                Reader.flag=false;
                    new collidethread();
                
                  
                } 
                
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
     
         a=NM.initialfirex;
        b=NM.initialfirex;
        c=NM.initialfirex;
        d=NM.initialfirex;
           NM.fireimage1.setX(a);
       NM.fireimage1.setY(b);
         NM.ullomboimage.setX(c);
       NM.ullomboimage.setY(d);
          NM.is_bomb_set_first_bomb=0;
   }else if((x>=0&&x<40)&&(y<=20&&y>=0)){
         a=NM.iMage.getX();//for bomb
       b=NM.iMage.getY()-10;
         c=NM.iMage.getX();//for bomb
       d=NM.iMage.getY();
       NM.iMage.setX(NM.initialbomb1x);
        NM.iMage.setY(NM.initialbomb1y);

         NM.fireimage1.setX(a);
         NM.fireimage1.setY(b);
         NM.ullomboimage.setX(c);
         NM.ullomboimage.setY(d);
           double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage.getY()+changeullomboy2>=thismany2)){
                 Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM.fireimage1.getX()+changefirex1<=thismanx1)&&(NM.fireimage1.getX()+changefirex2>=thismanx2)&&(NM.fireimage1.getY()+changefirey1<=thismany1)&&(NM.fireimage1.getY()+changefirey2>=thismany2)){
                  Reader.flag=false;
                    new collidethread();
                  
                } 
                
      //}
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }

    
         a=NM.initialfirex;
        b=NM.initialfirex;
        c=NM.initialfirex;
        d=NM.initialfirex;
           NM.fireimage1.setX(a);
       NM.fireimage1.setY(b);
         NM.ullomboimage.setX(c);
       NM.ullomboimage.setY(d);
          NM.is_bomb_set_first_bomb=0;
   }else if((x>580&&x<=600)&&(y<=20&&y>=0)){
        
       a=NM.iMage.getX()-200;//for bomb fourthbomb
       b=NM.iMage.getY();
         c=NM.iMage.getX()+10;//for bomb
       d=NM.iMage.getY();
        NM.iMage.setX(NM.initialbomb1x);
        NM.iMage.setY(NM.initialbomb1y);

         NM.fireimage1.setX(a);
         NM.fireimage1.setY(b);
         NM.ullomboimage.setX(c);
         NM.ullomboimage.setY(d);
           double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage.getY()+changeullomboy2>=thismany2)){
                 Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM.fireimage1.getX()+changefirex1<=thismanx1)&&(NM.fireimage1.getX()+changefirex2>=thismanx2)&&(NM.fireimage1.getY()+changefirey1<=thismany1)&&(NM.fireimage1.getY()+changefirey2>=thismany2)){
                    
                  Reader.flag=false;
                    new collidethread();
                  
                } 
                
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }

    
         a=NM.initialfirex;
        b=NM.initialfirex;
        c=NM.initialfirex;
        d=NM.initialfirex;
           NM.fireimage1.setX(a);
       NM.fireimage1.setY(b);
         NM.ullomboimage.setX(c);
       NM.ullomboimage.setY(d);
          NM.is_bomb_set_first_bomb=0;
   }
   }
}

