/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nm;

import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

/**
 *
 * @author User
 */
public class collidethread implements Runnable{
         final URL resource = getClass().getResource("Fire.wav");
    final Media media = new Media(resource.toString());
    final MediaPlayer mediaPlayer = new MediaPlayer(media);
    public collidethread(){
        
        new Thread(this).start();
    }
    @Override
    public void run() {
        if(NM.number_of_lives_left==5){
                  
       mediaPlayer.play();

            NM.life5.setX(2000);
            NM.life5.setX(2000);
             NM.number_of_lives_left--;
            
            
        }else if(NM.number_of_lives_left==4){
             mediaPlayer.play();
            NM.life4.setX(2000);
            NM.life4.setY(2000);
             NM.number_of_lives_left--;
             
        }else if(NM.number_of_lives_left==3){
             mediaPlayer.play();
            NM.life3.setX(2000);
            NM.life3.setY(2000);
             NM.number_of_lives_left--;
            
        }else if(NM.number_of_lives_left==2){
             mediaPlayer.play();
            NM.life2.setX(2000);
            NM.life2.setY(2000);
             NM.number_of_lives_left--;
             
        }else if(NM.number_of_lives_left==1){
             mediaPlayer.play();
            NM.life1.setX(2000);
            NM.life1.setY(2000);
             NM.number_of_lives_left--;
             NM.gameover.setX(0);
                NM.gameover.setY(0);
            try {
                Thread.sleep(300);
                System.exit(0);
            } catch (InterruptedException ex) {
                Logger.getLogger(collidethread.class.getName()).log(Level.SEVERE, null, ex);
            }
            
             
        }try{
            
            Thread.sleep(2000);
             Reader.flag=true;
           
        }catch(Exception e){
            
            
            System.out.println("got it");
        }
    }
    
}
