package nm;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.logging.Level;
import java.util.logging.Logger;
import nm.NM;
import static nm.NM.m;
import static nm.NM.n;
import static nm.NM.o;
import static nm.NM.p;

/**
 *
 * @author User
 */
public class fourththread implements Runnable{
       public void run(){ 
       
        
        try{
          
            Thread.sleep(5000);
 
        }catch(Exception e){
            System.out.println("interrupted");
        }
       double x=NM.iMage4.getX();
       double y=NM.iMage4.getY();
        
       if((x>580&&x<=600)&&(y<=600&&y>580)){
        
       m=NM.iMage4.getX()-200;//for bomb fourthbomb
       n=NM.iMage4.getY();
       o=NM.iMage4.getX()+10;//for bomb
       p=NM.iMage4.getY()-157;
        NM.iMage4.setX(NM.initialbomb1x);
        NM.iMage4.setY(NM.initialbomb1y);

         NM.fireimage4.setX(m);
         NM.fireimage4.setY(n);
         NM.ullomboimage4.setX(o);
         NM.ullomboimage4.setY(p);
          double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM.fireimage4.getX()+changefirex1<=thismanx1)&&(NM.fireimage4.getX()+changefirex2>=thismanx2)&&(NM.fireimage4.getY()+changefirey1<=thismany1)&&(NM.fireimage4.getY()+changefirey2>=thismany2)){
                    Reader.flag=false;
                    new collidethread();
                  
                } 
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
        m=NM.initialfirex;
        n=NM.initialfirex;
        o=NM.initialfirex;
        p=NM.initialfirex;
           NM.fireimage4.setX(m);
       NM.fireimage4.setY(n);
         NM.ullomboimage4.setX(o);
       NM.ullomboimage4.setY(p);
          NM.is_bomb_set_fourth_bomb=0;
 
       }else if((x>=0&&x<40)&&(y<=600&&y>580)){
         m=NM.iMage4.getX();//for bomb
       n=NM.iMage4.getY();
         o=NM.iMage4.getX();//for bomb
       p=NM.iMage4.getY()-157;
       NM.iMage4.setX(NM.initialbomb1x);
        NM.iMage4.setY(NM.initialbomb1y);

         NM.fireimage4.setX(m);
         NM.fireimage4.setY(n);
         NM.ullomboimage4.setX(o);
         NM.ullomboimage4.setY(p);
          double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM.fireimage4.getX()+changefirex1<=thismanx1)&&(NM.fireimage4.getX()+changefirex2>=thismanx2)&&(NM.fireimage4.getY()+changefirey1<=thismany1)&&(NM.fireimage4.getY()+changefirey2>=thismany2)){
                    
                   Reader.flag=false;
                    new collidethread();
                  
                } 
      //}
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
          m=NM.initialfirex;
        n=NM.initialfirex;
        o=NM.initialfirex;
        p=NM.initialfirex;
           NM.fireimage4.setX(m);
       NM.fireimage4.setY(n);
         NM.ullomboimage4.setX(o);
       NM.ullomboimage4.setY(p);
          NM.is_bomb_set_fourth_bomb=0;
    
    }else if((y==600||(y>420&&y<470)||(y>270&&y<330)||(y>=130&&y<=170)||(y>=0&&y<=20))&&((x>=40&&x<=130)||(x>=190&&x<=280)||(x>=340&&x<=430)||(x>=490&&x<=580))){
       m=NM.iMage4.getX()-100;//for first bomb
       n=NM.iMage4.getY();
       NM.iMage4.setX(NM.initialbomb1x);
        NM.iMage4.setY(NM.initialbomb1y);

        NM.fireimage4.setX(m);
        NM.fireimage4.setY(n);
       
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                
                if(Reader.flag&&(NM.fireimage4.getX()+changefirex1<=thismanx1)&&(NM.fireimage4.getX()+changefirex2>=thismanx2)&&(NM.fireimage4.getY()+changefirey1<=thismany1)&&(NM.fireimage4.getY()+changefirey2>=thismany2)){
                    Reader.flag=false;
                    new collidethread();
                } 
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
        m=NM.initialfirex;
        n=NM.initialfirey;
        NM.fireimage4.setX(m);
        NM.fireimage4.setY(n);
     
       NM.is_bomb_set_fourth_bomb=0;
   }else if((y==600)&&((x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490))){
       m=NM.iMage4.getX()-100;// 3rd bomb
       n=NM.iMage4.getY();
       o=NM.iMage4.getX();//for bomb
       p=NM.iMage4.getY()-157;
         NM.iMage4.setX(NM.initialbomb1x);
        NM.iMage4.setY(NM.initialbomb1y);
         NM.fireimage4.setX(m);
         NM.fireimage4.setY(n);
         NM.ullomboimage4.setX(o);
         NM.ullomboimage4.setY(p);
          double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM.fireimage4.getX()+changefirex1<=thismanx1)&&(NM.fireimage4.getX()+changefirex2>=thismanx2)&&(NM.fireimage4.getY()+changefirey1<=thismany1)&&(NM.fireimage4.getY()+changefirey2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                } 
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
           m=NM.initialfirex;
        n=NM.initialfirex;
        o=NM.initialfirex;
        p=NM.initialfirex;
           NM.fireimage4.setX(m);
       NM.fireimage4.setY(n);
         NM.ullomboimage4.setX(o);
       NM.ullomboimage4.setY(p);
     
          NM.is_bomb_set_fourth_bomb=0;
   }else if(((y>=470&&y<=580)||(y>=330&&y<=420)||(y>=180&&y<=270)||(y>=30&&y<=120))&&((x>0&&x<40)||(x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490)||(x>580&&x<=600))){//commonfifth
       o=NM.iMage4.getX()+10;//for fifth bomb
       p=NM.iMage4.getY()-70;
       NM.iMage4.setX(NM.initialbomb1x);
        NM.iMage4.setY(NM.initialbomb1y);
        NM.ullomboimage4.setX(o);
        NM.ullomboimage4.setY(p);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
               
                if(Reader.flag&&(NM.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                } 
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
        o=NM.initialfirex;
        p=NM.initialfirey;
        NM.ullomboimage4.setX(o);
       NM.ullomboimage4.setY(p);
       NM.is_bomb_set_fourth_bomb=0;
   }else if(((y<470&&y>420)||(y>270&&y<330)||(y>=130&&y<=170))&&(x>=0&&x<40)){
       m=NM.iMage4.getX();//for sixth bomb
       n=NM.iMage4.getY()-10;
         o=NM.iMage4.getX()+10;//for bomb
       p=NM.iMage4.getY()-70;
         NM.iMage4.setX(NM.initialbomb1x);
        NM.iMage4.setY(NM.initialbomb1y);
         NM.fireimage4.setX(m);
         NM.fireimage4.setY(n);
         NM.ullomboimage4.setX(o);
         NM.ullomboimage4.setY(p);
          double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM.fireimage4.getX()+changefirex1<=thismanx1)&&(NM.fireimage4.getX()+changefirex2>=thismanx2)&&(NM.fireimage4.getY()+changefirey1<=thismany1)&&(NM.fireimage4.getY()+changefirey2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                } 
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
           m=NM.initialfirex;
        n=NM.initialfirex;
        o=NM.initialfirex;
        p=NM.initialfirex;
           NM.fireimage4.setX(m);
     NM.fireimage4.setY(n);
         NM.ullomboimage4.setX(o);
       NM.ullomboimage4.setY(p);
   
          NM.is_bomb_set_fourth_bomb=0;
   }
       else if(((y>420&&y<470)||(y>270&&y<330)||(y>=130&&y<=170))&&(x>580&&x<=600)){
       m=NM.iMage4.getX()-200;// 3rd bomb
       n=NM.iMage4.getY();
         o=NM.iMage4.getX()+10;//for bomb
       p=NM.iMage4.getY()-79;
         NM.iMage4.setX(NM.initialbomb1x);
        NM.iMage4.setY(NM.initialbomb1y);
         NM.fireimage4.setX(m);
         NM.fireimage4.setY(n);
         NM.ullomboimage4.setX(o);
         NM.ullomboimage4.setY(p);
          double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM.fireimage4.getX()+changefirex1<=thismanx1)&&(NM.fireimage4.getX()+changefirex2>=thismanx2)&&(NM.fireimage4.getY()+changefirey1<=thismany1)&&(NM.fireimage4.getY()+changefirey2>=thismany2)){
                    
                   Reader.flag=false;
                    new collidethread();
                  
                } 
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
    
          m=NM.initialfirex;
        n=NM.initialfirex;
        o=NM.initialfirex;
        p=NM.initialfirex;
           NM.fireimage4.setX(m);
       NM.fireimage4.setY(n);
         NM.ullomboimage4.setX(o);
       NM.ullomboimage4.setY(p);
          NM.is_bomb_set_fourth_bomb=0;
   }else if(((y>420&&y<470)||(y>270&&y<330)||(y>=130&&y<=170))&&((x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490))){
       m=NM.iMage4.getX()-100;// 3rd bomb
       n=NM.iMage4.getY();
         o=NM.iMage4.getX()+10;//for bomb
       p=NM.iMage4.getY()-79;
         NM.iMage4.setX(NM.initialbomb1x);
        NM.iMage4.setY(NM.initialbomb1y);
         NM.fireimage4.setX(m);
         NM.fireimage4.setY(n);
         NM.ullomboimage4.setX(o);
         NM.ullomboimage4.setY(p);
          double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM.fireimage4.getX()+changefirex1<=thismanx1)&&(NM.fireimage4.getX()+changefirex2>=thismanx2)&&(NM.fireimage4.getY()+changefirey1<=thismany1)&&(NM.fireimage4.getY()+changefirey2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                } 
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
      
         m=NM.initialfirex;
        n=NM.initialfirex;
        o=NM.initialfirex;
       p=NM.initialfirex;
           NM.fireimage4.setX(m);
       NM.fireimage4.setY(n);
         NM.ullomboimage4.setX(o);
       NM.ullomboimage4.setY(p);

          NM.is_bomb_set_fourth_bomb=0;
   }else if((y>=0&&y<=20)&&((x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490))){
       m=NM.iMage4.getX()-100;// 3rd bomb
       n=NM.iMage4.getY();
         o=NM.iMage4.getX();//for bomb
       p=NM.iMage4.getY();
         NM.iMage4.setX(NM.initialbomb1x);
        NM.iMage4.setY(NM.initialbomb1y);
         NM.fireimage4.setX(m);
         NM.fireimage4.setY(n);
         NM.ullomboimage4.setX(o);
         NM.ullomboimage4.setY(p);
          double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM.fireimage4.getX()+changefirex1<=thismanx1)&&(NM.fireimage4.getX()+changefirex2>=thismanx2)&&(NM.fireimage4.getY()+changefirey1<=thismany1)&&(NM.fireimage4.getY()+changefirey2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                } 
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
     
         m=NM.initialfirex;
        n=NM.initialfirex;
        o=NM.initialfirex;
        p=NM.initialfirex;
           NM.fireimage4.setX(m);
       NM.fireimage4.setY(n);
         NM.ullomboimage4.setX(o);
       NM.ullomboimage4.setY(p);
          NM.is_bomb_set_fourth_bomb=0;
   }else if((x>=0&&x<40)&&(y<=20&&y>=0)){
         m=NM.iMage4.getX();//for bomb
       n=NM.iMage4.getY()-10;
         o=NM.iMage4.getX();//for bomb
       p=NM.iMage4.getY();
       NM.iMage4.setX(NM.initialbomb1x);
        NM.iMage4.setY(NM.initialbomb1y);

         NM.fireimage4.setX(m);
         NM.fireimage4.setY(n);
         NM.ullomboimage4.setX(o);
         NM.ullomboimage4.setY(p);
          double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM.fireimage4.getX()+changefirex1<=thismanx1)&&(NM.fireimage4.getX()+changefirex2>=thismanx2)&&(NM.fireimage4.getY()+changefirey1<=thismany1)&&(NM.fireimage4.getY()+changefirey2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                  
                } 
      //}
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }

    
         m=NM.initialfirex;
        n=NM.initialfirex;
        o=NM.initialfirex;
        p=NM.initialfirex;
           NM.fireimage4.setX(m);
       NM.fireimage4.setY(n);
         NM.ullomboimage4.setX(o);
       NM.ullomboimage4.setY(p);
          NM.is_bomb_set_fourth_bomb=0;
   }else if((x>580&&x<=600)&&(y<=20&&y>=0)){
        
       m=NM.iMage4.getX()-200;//for bomb fourthbomb
       n=NM.iMage4.getY();
         o=NM.iMage4.getX()+10;//for bomb
       p=NM.iMage4.getY();
        NM.iMage4.setX(NM.initialbomb1x);
       NM.iMage4.setY(NM.initialbomb1y);

         NM.fireimage4.setX(m);
         NM.fireimage4.setY(n);
         NM.ullomboimage4.setX(o);
         NM.ullomboimage4.setY(p);
          double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM.fireimage4.getX()+changefirex1<=thismanx1)&&(NM.fireimage4.getX()+changefirex2>=thismanx2)&&(NM.fireimage4.getY()+changefirey1<=thismany1)&&(NM.fireimage4.getY()+changefirey2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                  
                } 
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }

    
         m=NM.initialfirex;
        n=NM.initialfirex;
        o=NM.initialfirex;
        p=NM.initialfirex;
           NM.fireimage4.setX(m);
       NM.fireimage4.setY(n);
         NM.ullomboimage4.setX(o);
       NM.ullomboimage4.setY(p);
          NM.is_bomb_set_fourth_bomb=0;
   }
   }
    
}

    


    

