/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nm;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import util.data;
import util.data_for_ducks;
import util.networkutil;

/**
 *
 * @author User
 */
public class Writer implements Runnable{
    
    public networkutil connection;
    
    public Writer(networkutil nc){
        connection = nc;
      
    }

    @Override
    public void run() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Writer.class.getName()).log(Level.SEVERE, null, ex);
        }
     
        while(true){
             
           
            try {
                //      String msg=in.nextLine();
                Thread.sleep(100);
              //    System.out.println("written");
                data_for_ducks d=new data_for_ducks(nm.NM.image.getX(),nm.NM.image.getY(),nm.NM.iMage.getX(),nm.NM.iMage.getY(),nm.NM.iMage2.getX(),nm.NM.iMage2.getY(),nm.NM.iMage3.getX(),nm.NM.iMage3.getY(),nm.NM.iMage4.getX(),nm.NM.iMage4.getY(),nm.NM.ullomboimage.getX(),nm.NM.ullomboimage.getY(),nm.NM.fireimage1.getX(),nm.NM.fireimage1.getY(),nm.NM.ullomboimage2.getX(),nm.NM.ullomboimage2.getY(),nm.NM.fireimage2.getX(),nm.NM.fireimage2.getY(),nm.NM.ullomboimage3.getX(),nm.NM.ullomboimage3.getY(),nm.NM.fireimage3.getX(),nm.NM.fireimage3.getY(),nm.NM.ullomboimage4.getX(),nm.NM.ullomboimage4.getY(),nm.NM.fireimage4.getX(),nm.NM.fireimage4.getY(),nm.NM.number_of_lives_left,nm.NM.ducks1.getX(),nm.NM.ducks1.getY(),nm.NM.ducks2.getX(),nm.NM.ducks2.getY(),nm.NM.ducks3.getX(),nm.NM.ducks3.getY(),nm.NM.ducks4.getX(),nm.NM.ducks4.getY(),nm.NM.ducks5.getX(),nm.NM.ducks5.getY());//nm.NM.iMage4.getX(),nm.NM.iMage4.getY()); 
              //  data d=new data(0,1,2,3);
                connection.write(d);
              
                
                
            } catch (InterruptedException ex) {
              //  System.out.println("dd");
            }
           
        }
    }
    
}
