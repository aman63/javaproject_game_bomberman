/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nm;

/**
 *
 * @author User
 */
public class colon {
      double vx;
    double vy;
    public int indicator;
  double x;
  double y;
   
    public colon(double x,double y,double vvx,double vvy,int indicator){
        this.x=x;
        this.y=y;
        this.vx=vvx;
        this.vy=vvy;
        this.indicator=indicator;
    }
     public void updateCenter(double time){
        x+=vx*time*2.5;
        y+=vy*time*2.5;
        System.out.println(x+" "+y);
        switch(indicator){
            case 1:
                NM.ducks1.setX(x);
                 NM.ducks1.setY(y);
                 break;
            case 2:
                NM.ducks2.setX(x);
                 NM.ducks2.setY(y);
                 break;
              case 3:
                NM.ducks3.setX(x);
                 NM.ducks3.setY(y);
                 break;
              case 4:
                NM.ducks4.setX(x);
                 NM.ducks4.setY(y);
                 break;
               case 5:
                NM.ducks5.setX(x);
                NM.ducks5.setY(y);
                 break;
              
        }
        double changeduckx=60;
                double changeducky=84;
                 double thismanx1=NM.image.getX();
                double thismanx2=NM.image.getX()+60; 
                double thismany1=NM.image.getY();
                double thismany2=NM.image.getY()+60;
         if(Reader.flag&&(((NM.ducks1.getX()<=thismanx1+20)&&(NM.ducks1.getX()+changeduckx>=thismanx2-20)&&(NM.ducks1.getY()<=thismany1+20)&&(NM.ducks1.getY()+changeducky>=thismany2-20))||((NM.ducks2.getX()<=thismanx1+20)&&(NM.ducks2.getX()+changeduckx>=thismanx2-20)&&(NM.ducks2.getY()<=thismany1+20)&&(NM.ducks2.getY()+changeducky>=thismany2-20))||((NM.ducks3.getX()<=thismanx1+20)&&(NM.ducks3.getX()+changeduckx>=thismanx2-20)&&(NM.ducks3.getY()<=thismany1+20)&&(NM.ducks3.getY()+changeducky>=thismany2-20))||((NM.ducks4.getX()<=thismanx1+20)&&(NM.ducks4.getX()+changeduckx>=thismanx2-20)&&(NM.ducks4.getY()<=thismany1+20)&&(NM.ducks4.getY()+changeducky>=thismany2-20))||((NM.ducks5.getX()<=thismanx1+20)&&(NM.ducks5.getX()+changeduckx>=thismanx2-20)&&(NM.ducks5.getY()<=thismany1+20)&&(NM.ducks5.getY()+changeducky>=thismany2-20)))){
                    Reader.flag=false;
                    new collidethread();
                    System.out.println("hh");
                     } 
         
    }
      public void collision(){
     
        double X=675;
        double Y=675;
        
        if(x+60>=X ||x<0)vx=-vx;
        if(y+84>Y||y<0)vy=-vy;
        
        //System.out.println(x+" "+y+" "+getCenterX()+" "+getCenterY() );
    }
}
