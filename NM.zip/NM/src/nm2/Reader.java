/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package nm2;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import util.data;
import util.data_for_ducks;
import util.networkutil;


/**
 *
 * @author User
 */
public class Reader implements Runnable{
     public networkutil connection;
    public static boolean flag=true;
    public Reader(networkutil nc){
        connection = nc;
    }

    @Override
    public void run() {
       
       data_for_ducks D;
       
        while(true){
           
          try{
           
            Object o=connection.read();
            
        //    System.out.println("connection read");
            
          if( o instanceof data_for_ducks){
              D=(data_for_ducks)o;
                
                     NM2.ducks1.setX(D.d1x);
                NM2.ducks1.setY(D.d1y);
                      NM2.ducks2.setX(D.d2x);
                NM2.ducks2.setY(D.d2y);
                  NM2.ducks3.setX(D.d3x);
                NM2.ducks3.setY(D.d3y);
                  NM2.ducks4.setX(D.d4x);
                NM2.ducks4.setY(D.d4y);
                 NM2.ducks5.setX(D.d5x);
                NM2.ducks5.setY(D.d5y);
           //   System.out.println("REceived");
             //System.out.println(D.x+" "+D.y+" "+D.X+" "+D.Y);
               NM2.image2.setX(D.x);
                NM2.image2.setY(D.y);            
                NM2.secondplayer_iMage1.setX(D.secondplayer_bomb1_x);
                NM2.secondplayer_iMage1.setY(D.secondplayer_bomb1_y);
                   NM2.secondplayer_iMage2.setX(D.secondplayer_bomb2_x);
                NM2.secondplayer_iMage2.setY(D.secondplayer_bomb2_y);
                   NM2.secondplayer_iMage3.setX(D.secondplayer_bomb3_x);
                NM2.secondplayer_iMage3.setY(D.secondplayer_bomb3_y);
                   NM2.secondplayer_iMage4.setX(D.secondplayer_bomb4_x);
                NM2.secondplayer_iMage4.setY(D.secondplayer_bomb4_y);
                NM2.secondplayer_ullomboimage1.setX(D.secondplayer_ullomboimage1_x);
                NM2.secondplayer_ullomboimage1.setY(D.secondplayer_ullomboimage1_y);
                  NM2.secondplayer_fireimage1.setX(D.secondplayer_fireimage1_x);
                NM2.secondplayer_fireimage1.setY(D.secondplayer_fireimage1_y);
                 NM2.secondplayer_ullomboimage2.setX(D.secondplayer_ullomboimage2_x);
                NM2.secondplayer_ullomboimage2.setY(D.secondplayer_ullomboimage2_y);
                  NM2.secondplayer_fireimage2.setX(D.secondplayer_fireimage2_x);
                NM2.secondplayer_fireimage2.setY(D.secondplayer_fireimage2_y);
                   NM2.secondplayer_ullomboimage3.setX(D.secondplayer_ullomboimage3_x);
                NM2.secondplayer_ullomboimage3.setY(D.secondplayer_ullomboimage3_y);
                  NM2.secondplayer_fireimage3.setX(D.secondplayer_fireimage3_x);
                NM2.secondplayer_fireimage3.setY(D.secondplayer_fireimage3_y);
                 NM2.secondplayer_ullomboimage4.setX(D.secondplayer_ullomboimage4_x);
                NM2.secondplayer_ullomboimage4.setY(D.secondplayer_ullomboimage4_y);
                  NM2.secondplayer_fireimage4.setX(D.secondplayer_fireimage4_x);
                NM2.secondplayer_fireimage4.setY(D.secondplayer_fireimage4_y);
                    NM2.secondplayer_number_of_lives_left=D.number_of_lives_for_secondplayer;
                  
                 if(NM2.secondplayer_number_of_lives_left<NM2.prev_secondplayer_number_of_lives_left){
                    new lifeshow_forsecondplayer();
                }
                  double changeullombox=27;
                double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
             
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                double changeduckx=60;
                double changeducky=84;
                if(flag&&(((NM2.ducks1.getX()<=thismanx1+20)&&(NM2.ducks1.getX()+changeduckx>=thismanx2-20)&&(NM2.ducks1.getY()<=thismany1+20)&&(NM2.ducks1.getY()+changeducky>=thismany2-20))||((NM2.ducks5.getX()<=thismanx1+20)&&(NM2.ducks5.getX()+changeduckx>=thismanx2-20)&&(NM2.ducks5.getY()<=thismany1+20)&&(NM2.ducks5.getY()+changeducky>=thismany2-20))||((NM2.ducks4.getX()<=thismanx1+20)&&(NM2.ducks4.getX()+changeduckx>=thismanx2-20)&&(NM2.ducks4.getY()<=thismany1+20)&&(NM2.ducks4.getY()+changeducky>=thismany2-20))||((NM2.ducks2.getX()<=thismanx1+20)&&(NM2.ducks2.getX()+changeduckx>=thismanx2-20)&&(NM2.ducks2.getY()<=thismany1+20)&&(NM2.ducks2.getY()+changeducky>=thismany2-20))||((NM2.ducks3.getX()<=thismanx1+20)&&(NM2.ducks3.getX()+changeduckx>=thismanx2-20)&&(NM2.ducks3.getY()<=thismany1+20)&&(NM2.ducks3.getY()+changeducky>=thismany2-20)))){
                    flag=false;
                    new collidethread();
                    System.out.println("hh");
                }
                else if(flag&&(NM2.secondplayer_ullomboimage1.getX()+changeullombox1<=thismanx1)&&(NM2.secondplayer_ullomboimage1.getX()+changeullombox2>=thismanx2)&&(NM2.secondplayer_ullomboimage1.getY()+changeullomboy1<=thismany1)&&(NM2.secondplayer_ullomboimage1.getY()+changeullomboy2>=thismany2)){
                    flag=false;
                    new collidethread();
                    System.out.println("hh");
                }else if(flag&&(NM2.secondplayer_ullomboimage2.getX()+changeullombox1<=thismanx1)&&(NM2.secondplayer_ullomboimage2.getX()+changeullombox2>=thismanx2)&&(NM2.secondplayer_ullomboimage2.getY()+changeullomboy1<=thismany1)&&(NM2.secondplayer_ullomboimage2.getY()+changeullomboy2>=thismany2)){
                   flag=false;
                    new collidethread();
                    System.out.println("hh");
                }else if(flag&&(NM2.secondplayer_ullomboimage3.getX()+changeullombox1<=thismanx1)&&(NM2.secondplayer_ullomboimage3.getX()+changeullombox2>=thismanx2)&&(NM2.secondplayer_ullomboimage3.getY()+changeullomboy1<=thismany1)&&(NM2.secondplayer_ullomboimage3.getY()+changeullomboy2>=thismany2)){
                    flag=false;
                    new collidethread();
                    System.out.println("hh");
                }else if(flag&&(NM2.secondplayer_ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM2.secondplayer_ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM2.secondplayer_ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM2.secondplayer_ullomboimage4.getY()+changeullomboy2>=thismany2)){
                    flag=false;
                    new collidethread();
                    System.out.println("hh");
                }else if(flag&&(NM2.secondplayer_fireimage1.getX()+changefirex1<=thismanx1)&&(NM2.secondplayer_fireimage1.getX()+changefirex2>=thismanx2)&&(NM2.secondplayer_fireimage1.getY()+changefirey1<=thismany1)&&(NM2.secondplayer_fireimage1.getY()+changefirey2>=thismany2)){
                    System.out.println("hu");
                    flag=false;
                    new collidethread();
                }else if(flag&&(NM2.secondplayer_fireimage2.getX()+changefirex1<=thismanx1)&&(NM2.secondplayer_fireimage2.getX()+changefirex2>=thismanx2)&&(NM2.secondplayer_fireimage2.getY()+changefirey1<=thismany1)&&(NM2.secondplayer_fireimage2.getY()+changefirey2>=thismany2)){
                   flag=false;
                    System.out.println("hh");
                    new collidethread();
                }else if(flag&&(NM2.secondplayer_fireimage3.getX()+changefirex1<=thismanx1)&&(NM2.secondplayer_fireimage3.getX()+changefirex2>=thismanx2)&&(NM2.secondplayer_fireimage3.getY()+changefirey1<=thismany1)&&(NM2.secondplayer_fireimage3.getY()+changefirey2>=thismany2)){
                   flag=false;
                    System.out.println("hh");
                    new collidethread();
                }else if(flag&&(NM2.secondplayer_fireimage4.getX()+changefirex1<=thismanx1)&&(NM2.secondplayer_fireimage4.getX()+changefirex2>=thismanx2)&&(NM2.secondplayer_fireimage4.getY()+changefirey1<=thismany1)&&(NM2.secondplayer_fireimage4.getY()+changefirey2>=thismany2)){
                    flag=false;
                    System.out.println("hh");
                    new collidethread();
                }
        
                
          }
            
        /*  else if(o instanceof data_for_ducks){
              Duck=(data_for_ducks)o;
              NM2.ducks1.setX(Duck.d1x);
                NM2.ducks1.setY(Duck.d1y);
                  NM2.ducks2.setX(Duck.d2x);
                NM2.ducks2.setY(Duck.d2y);
                  NM2.ducks3.setX(Duck.d3x);
                NM2.ducks3.setY(Duck.d3y);
                System.out.println("it");
          }*/
            }catch(Exception e){
                  //  System.out.println("ss");
                    }
          
        }
    }
    }


