/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nm2;

import nm2.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import static nm2.NM2.i;
import static nm2.NM2.j;
import static nm2.NM2.k;
import static nm2.NM2.l;

/**
 *
 * @author User
 */
public class thirdthread implements Runnable{
     public void run(){ 
       
        
        try{
          
            Thread.sleep(5000);
 
        }catch(Exception e){
            System.out.println("interrupted");
        }
       double x=NM2.iMage3.getX();
       double y=NM2.iMage3.getY();
        
       if((x>580&&x<=600)&&(y<=600&&y>580)){
        
       i=NM2.iMage3.getX()-200;//for bomb fourthbomb
       j=NM2.iMage3.getY();
       k=NM2.iMage3.getX()+10;//for bomb
       l=NM2.iMage3.getY()-157;
        NM2.iMage3.setX(NM2.initialbomb1x);
        NM2.iMage3.setY(NM2.initialbomb1y);

         NM2.fireimage3.setX(i);
         NM2.fireimage3.setY(j);
         NM2.ullomboimage3.setX(k);
         NM2.ullomboimage3.setY(l);
           double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage3.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage3.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage3.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage3.getY()+changeullomboy2>=thismany2)){
                   
                 Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM2.fireimage3.getX()+changefirex1<=thismanx1)&&(NM2.fireimage3.getX()+changefirex2>=thismanx2)&&(NM2.fireimage3.getY()+changefirey1<=thismany1)&&(NM2.fireimage3.getY()+changefirey2>=thismany2)){
                    
                 Reader.flag=false;
                    new collidethread();
                  
                } 
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
        i=NM2.initialfirex;
        j=NM2.initialfirex;
        k=NM2.initialfirex;
        l=NM2.initialfirex;
           NM2.fireimage3.setX(i);
       NM2.fireimage3.setY(j);
         NM2.ullomboimage3.setX(k);
       NM2.ullomboimage3.setY(l);
          NM2.is_bomb_set_third_bomb=0;
 
       }else if((x>=0&&x<40)&&(y<=600&&y>580)){
         i=NM2.iMage3.getX();//for bomb
       j=NM2.iMage3.getY();
         k=NM2.iMage3.getX();//for bomb
       l=NM2.iMage3.getY()-157;
       NM2.iMage3.setX(NM2.initialbomb1x);
        NM2.iMage3.setY(NM2.initialbomb1y);

         NM2.fireimage3.setX(i);
         NM2.fireimage3.setY(j);
         NM2.ullomboimage3.setX(k);
         NM2.ullomboimage3.setY(l);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage3.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage3.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage3.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage3.getY()+changeullomboy2>=thismany2)){
                   
                 Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM2.fireimage3.getX()+changefirex1<=thismanx1)&&(NM2.fireimage3.getX()+changefirex2>=thismanx2)&&(NM2.fireimage3.getY()+changefirey1<=thismany1)&&(NM2.fireimage3.getY()+changefirey2>=thismany2)){
                    
                 Reader.flag=false;
                    new collidethread();
                  
                } 
      
      //}
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
          i=NM2.initialfirex;
        j=NM2.initialfirex;
        k=NM2.initialfirex;
        l=NM2.initialfirex;
           NM2.fireimage3.setX(i);
       NM2.fireimage3.setY(j);
         NM2.ullomboimage3.setX(k);
       NM2.ullomboimage3.setY(l);
          NM2.is_bomb_set_third_bomb=0;
    
    }else if((y==600||(y>420&&y<470)||(y>270&&y<330)||(y>=130&&y<=170)||(y>=0&&y<=20))&&((x>=40&&x<=130)||(x>=190&&x<=280)||(x>=340&&x<=430)||(x>=490&&x<=580))){
       i=NM2.iMage3.getX()-100;//for first bomb
       j=NM2.iMage3.getY();
       NM2.iMage3.setX(NM2.initialbomb1x);
        NM2.iMage3.setY(NM2.initialbomb1y);

        NM2.fireimage3.setX(i);
        NM2.fireimage3.setY(j);
      
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
               
                 if(Reader.flag&&(NM2.fireimage3.getX()+changefirex1<=thismanx1)&&(NM2.fireimage3.getX()+changefirex2>=thismanx2)&&(NM2.fireimage3.getY()+changefirey1<=thismany1)&&(NM2.fireimage3.getY()+changefirey2>=thismany2)){
                    
                 Reader.flag=false;
                    new collidethread();
                  
                } 
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
        i=NM2.initialfirex;
        j=NM2.initialfirey;
        NM2.fireimage3.setX(i);
        NM2.fireimage3.setY(j);
     
       NM2.is_bomb_set_third_bomb=0;
   }else if((y==600)&&((x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490))){
       i=NM2.iMage3.getX()-100;// 3rd bomb
       j=NM2.iMage3.getY();
       k=NM2.iMage3.getX();//for bomb
       l=NM2.iMage3.getY()-157;
         NM2.iMage3.setX(NM2.initialbomb1x);
        NM2.iMage3.setY(NM2.initialbomb1y);
         NM2.fireimage3.setX(i);
         NM2.fireimage3.setY(j);
         NM2.ullomboimage3.setX(k);
         NM2.ullomboimage3.setY(l);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage3.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage3.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage3.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage3.getY()+changeullomboy2>=thismany2)){
                   
                 Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM2.fireimage3.getX()+changefirex1<=thismanx1)&&(NM2.fireimage3.getX()+changefirex2>=thismanx2)&&(NM2.fireimage3.getY()+changefirey1<=thismany1)&&(NM2.fireimage3.getY()+changefirey2>=thismany2)){
                    
                 Reader.flag=false;
                    new collidethread();
                  
                } 
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
           i=NM2.initialfirex;
        j=NM2.initialfirex;
        k=NM2.initialfirex;
        l=NM2.initialfirex;
           NM2.fireimage3.setX(i);
       NM2.fireimage3.setY(j);
         NM2.ullomboimage3.setX(k);
       NM2.ullomboimage3.setY(l);
     
          NM2.is_bomb_set_third_bomb=0;
   }else if(((y>=470&&y<=580)||(y>=330&&y<=420)||(y>=180&&y<=270)||(y>=30&&y<=120))&&((x>0&&x<40)||(x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490)||(x>580&&x<=600))){//commonfifth
       k=NM2.iMage3.getX()+10;//for fifth bomb
       l=NM2.iMage3.getY()-70;
       NM2.iMage3.setX(NM2.initialbomb1x);
        NM2.iMage3.setY(NM2.initialbomb1y);
        NM2.ullomboimage3.setX(k);
        NM2.ullomboimage3.setY(l);
        double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
               
                if(Reader.flag&&(NM2.ullomboimage3.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage3.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage3.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage3.getY()+changeullomboy2>=thismany2)){
                   
                 Reader.flag=false;
                    new collidethread();
                } 
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
        k=NM2.initialfirex;
        l=NM2.initialfirey;
        NM2.ullomboimage3.setX(k);
       NM2.ullomboimage3.setY(l);
       NM2.is_bomb_set_third_bomb=0;
   }else if(((y<470&&y>420)||(y>270&&y<330)||(y>=130&&y<=170))&&(x>=0&&x<40)){
       i=NM2.iMage3.getX();//for sixth bomb
       j=NM2.iMage3.getY()-10;
         k=NM2.iMage3.getX()+10;//for bomb
       l=NM2.iMage3.getY()-70;
         NM2.iMage3.setX(NM2.initialbomb1x);
        NM2.iMage3.setY(NM2.initialbomb1y);
         NM2.fireimage3.setX(i);
         NM2.fireimage3.setY(j);
         NM2.ullomboimage3.setX(k);
         NM2.ullomboimage3.setY(l);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage3.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage3.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage3.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage3.getY()+changeullomboy2>=thismany2)){
                   
                 Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM2.fireimage3.getX()+changefirex1<=thismanx1)&&(NM2.fireimage3.getX()+changefirex2>=thismanx2)&&(NM2.fireimage3.getY()+changefirey1<=thismany1)&&(NM2.fireimage3.getY()+changefirey2>=thismany2)){
                    
                 Reader.flag=false;
                    new collidethread();
                  
                } 
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
           i=NM2.initialfirex;
        j=NM2.initialfirex;
        k=NM2.initialfirex;
        l=NM2.initialfirex;
           NM2.fireimage3.setX(i);
       NM2.fireimage3.setY(j);
         NM2.ullomboimage3.setX(k);
       NM2.ullomboimage3.setY(l);
   
          NM2.is_bomb_set_third_bomb=0;
   }
       else if(((y>420&&y<470)||(y>270&&y<330)||(y>=130&&y<=170))&&(x>580&&x<=600)){
       i=NM2.iMage3.getX()-200;// 3rd bomb
       j=NM2.iMage3.getY();
         k=NM2.iMage3.getX()+10;//for bomb
       l=NM2.iMage3.getY()-79;
         NM2.iMage3.setX(NM2.initialbomb1x);
        NM2.iMage3.setY(NM2.initialbomb1y);
         NM2.fireimage3.setX(i);
         NM2.fireimage3.setY(j);
         NM2.ullomboimage3.setX(k);
         NM2.ullomboimage3.setY(l);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage3.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage3.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage3.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage3.getY()+changeullomboy2>=thismany2)){
                   
                 Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM2.fireimage3.getX()+changefirex1<=thismanx1)&&(NM2.fireimage3.getX()+changefirex2>=thismanx2)&&(NM2.fireimage3.getY()+changefirey1<=thismany1)&&(NM2.fireimage3.getY()+changefirey2>=thismany2)){
                    
                 Reader.flag=false;
                    new collidethread();
                  
                } 
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
    
          i=NM2.initialfirex;
        j=NM2.initialfirex;
        k=NM2.initialfirex;
        l=NM2.initialfirex;
           NM2.fireimage3.setX(i);
       NM2.fireimage3.setY(j);
         NM2.ullomboimage3.setX(k);
       NM2.ullomboimage3.setY(l);
          NM2.is_bomb_set_third_bomb=0;
   }else if(((y>420&&y<470)||(y>270&&y<330)||(y>=130&&y<=170))&&((x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490))){
       i=NM2.iMage3.getX()-100;// 3rd bomb
       j=NM2.iMage3.getY();
         k=NM2.iMage3.getX()+10;//for bomb
       l=NM2.iMage3.getY()-79;
         NM2.iMage3.setX(NM2.initialbomb1x);
        NM2.iMage3.setY(NM2.initialbomb1y);
         NM2.fireimage3.setX(i);
         NM2.fireimage3.setY(j);
         NM2.ullomboimage3.setX(k);
         NM2.ullomboimage3.setY(l);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage3.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage3.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage3.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage3.getY()+changeullomboy2>=thismany2)){
                   
                 Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM2.fireimage3.getX()+changefirex1<=thismanx1)&&(NM2.fireimage3.getX()+changefirex2>=thismanx2)&&(NM2.fireimage3.getY()+changefirey1<=thismany1)&&(NM2.fireimage3.getY()+changefirey2>=thismany2)){
                    
                 Reader.flag=false;
                    new collidethread();
                  
                } 
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
      
         i=NM2.initialfirex;
        j=NM2.initialfirex;
        k=NM2.initialfirex;
       l=NM2.initialfirex;
           NM2.fireimage3.setX(i);
       NM2.fireimage3.setY(j);
         NM2.ullomboimage3.setX(k);
       NM2.ullomboimage3.setY(l);

          NM2.is_bomb_set_third_bomb=0;
   }else if((y>=0&&y<=20)&&((x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490))){
       i=NM2.iMage3.getX()-100;// 3rd bomb
       j=NM2.iMage3.getY();
         k=NM2.iMage3.getX();//for bomb
       l=NM2.iMage3.getY();
         NM2.iMage3.setX(NM2.initialbomb1x);
        NM2.iMage3.setY(NM2.initialbomb1y);
         NM2.fireimage3.setX(i);
         NM2.fireimage3.setY(j);
         NM2.ullomboimage3.setX(k);
         NM2.ullomboimage3.setY(l);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage3.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage3.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage3.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage3.getY()+changeullomboy2>=thismany2)){
                   
                 Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM2.fireimage3.getX()+changefirex1<=thismanx1)&&(NM2.fireimage3.getX()+changefirex2>=thismanx2)&&(NM2.fireimage3.getY()+changefirey1<=thismany1)&&(NM2.fireimage3.getY()+changefirey2>=thismany2)){
                    
                 Reader.flag=false;
                    new collidethread();
                  
                } 
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
     
         i=NM2.initialfirex;
        j=NM2.initialfirex;
        k=NM2.initialfirex;
        l=NM2.initialfirex;
           NM2.fireimage3.setX(i);
       NM2.fireimage3.setY(j);
         NM2.ullomboimage3.setX(k);
       NM2.ullomboimage3.setY(l);
          NM2.is_bomb_set_third_bomb=0;
   }else if((x>=0&&x<40)&&(y<=20&&y>=0)){
         i=NM2.iMage3.getX();//for bomb
       j=NM2.iMage3.getY()-10;
         k=NM2.iMage3.getX();//for bomb
       l=NM2.iMage3.getY();
       NM2.iMage3.setX(NM2.initialbomb1x);
        NM2.iMage3.setY(NM2.initialbomb1y);

         NM2.fireimage3.setX(i);
         NM2.fireimage3.setY(j);
         NM2.ullomboimage3.setX(k);
         NM2.ullomboimage3.setY(l);
      //}
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }

    
         i=NM2.initialfirex;
        j=NM2.initialfirex;
        k=NM2.initialfirex;
        l=NM2.initialfirex;
           NM2.fireimage3.setX(i);
       NM2.fireimage3.setY(j);
         NM2.ullomboimage3.setX(k);
       NM2.ullomboimage3.setY(l);
          NM2.is_bomb_set_third_bomb=0;
   }else if((x>580&&x<=600)&&(y<=20&&y>=0)){
        
       i=NM2.iMage3.getX()-200;//for bomb fourthbomb
       j=NM2.iMage3.getY();
         k=NM2.iMage3.getX()+10;//for bomb
       l=NM2.iMage3.getY();
        NM2.iMage3.setX(NM2.initialbomb1x);
        NM2.iMage3.setY(NM2.initialbomb1y);

         NM2.fireimage3.setX(i);
         NM2.fireimage3.setY(j);
         NM2.ullomboimage3.setX(k);
         NM2.ullomboimage3.setY(l);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage3.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage3.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage3.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage3.getY()+changeullomboy2>=thismany2)){
                   
                 Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM2.fireimage3.getX()+changefirex1<=thismanx1)&&(NM2.fireimage3.getX()+changefirex2>=thismanx2)&&(NM2.fireimage3.getY()+changefirey1<=thismany1)&&(NM2.fireimage3.getY()+changefirey2>=thismany2)){
                    
                 Reader.flag=false;
                    new collidethread();
                  
                } 
      
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }

    
         i=NM2.initialfirex;
        j=NM2.initialfirex;
        k=NM2.initialfirex;
        l=NM2.initialfirex;
           NM2.fireimage3.setX(i);
       NM2.fireimage3.setY(j);
         NM2.ullomboimage3.setX(k);
       NM2.ullomboimage3.setY(l);
          NM2.is_bomb_set_third_bomb=0;
   }
   }
    
}

    

