/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nm2;

import nm2.*;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;

/**
 *
 * @author User
 */
public class music_play_thread implements Runnable{
      final URL resource = getClass().getResource("background_music.mp3");
    final Media media = new Media(resource.toString());
    final MediaPlayer mediaPlayer = new MediaPlayer(media);
    @Override
    public void run() {
            mediaPlayer.setOnEndOfMedia(new Runnable(){
                public void run(){
                     mediaPlayer.seek(Duration.ZERO);  
                }
            });
              
              mediaPlayer.play();
              /*  try {
                Thread.sleep(105000);
            } catch (InterruptedException ex) {
                Logger.getLogger(music_play_thread.class.getName()).log(Level.SEVERE, null, ex);
            }*/
    //}
        
    }
    
}
