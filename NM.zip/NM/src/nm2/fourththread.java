/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nm2;

import nm2.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import static nm2.NM2.m;
import static nm2.NM2.n;
import static nm2.NM2.o;
import static nm2.NM2.p;

/**
 *
 * @author User
 */
public class fourththread implements Runnable{
       public void run(){ 
       
        
        try{
          
            Thread.sleep(5000);
 
        }catch(Exception e){
            System.out.println("interrupted");
        }
       double x=NM2.iMage4.getX();
       double y=NM2.iMage4.getY();
        
       if((x>580&&x<=600)&&(y<=600&&y>580)){
        
       m=NM2.iMage4.getX()-200;//for bomb fourthbomb
       n=NM2.iMage4.getY();
       o=NM2.iMage4.getX()+10;//for bomb
       p=NM2.iMage4.getY()-157;
        NM2.iMage4.setX(NM2.initialbomb1x);
        NM2.iMage4.setY(NM2.initialbomb1y);

         NM2.fireimage4.setX(m);
         NM2.fireimage4.setY(n);
         NM2.ullomboimage4.setX(o);
         NM2.ullomboimage4.setY(p);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM2.fireimage4.getX()+changefirex1<=thismanx1)&&(NM2.fireimage4.getX()+changefirex2>=thismanx2)&&(NM2.fireimage4.getY()+changefirey1<=thismany1)&&(NM2.fireimage4.getY()+changefirey2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                  
                } 
      
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
        m=NM2.initialfirex;
        n=NM2.initialfirex;
        o=NM2.initialfirex;
        p=NM2.initialfirex;
           NM2.fireimage4.setX(m);
       NM2.fireimage4.setY(n);
         NM2.ullomboimage4.setX(o);
       NM2.ullomboimage4.setY(p);
          NM2.is_bomb_set_fourth_bomb=0;
 
       }else if((x>=0&&x<40)&&(y<=600&&y>580)){
         m=NM2.iMage4.getX();//for bomb
       n=NM2.iMage4.getY();
         o=NM2.iMage4.getX();//for bomb
       p=NM2.iMage4.getY()-157;
       NM2.iMage4.setX(NM2.initialbomb1x);
        NM2.iMage4.setY(NM2.initialbomb1y);

         NM2.fireimage4.setX(m);
         NM2.fireimage4.setY(n);
         NM2.ullomboimage4.setX(o);
         NM2.ullomboimage4.setY(p);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM2.fireimage4.getX()+changefirex1<=thismanx1)&&(NM2.fireimage4.getX()+changefirex2>=thismanx2)&&(NM2.fireimage4.getY()+changefirey1<=thismany1)&&(NM2.fireimage4.getY()+changefirey2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                  
                } 
      
      //}
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
          m=NM2.initialfirex;
        n=NM2.initialfirex;
        o=NM2.initialfirex;
        p=NM2.initialfirex;
           NM2.fireimage4.setX(m);
       NM2.fireimage4.setY(n);
         NM2.ullomboimage4.setX(o);
       NM2.ullomboimage4.setY(p);
          NM2.is_bomb_set_fourth_bomb=0;
    
    }else if((y==600||(y>420&&y<470)||(y>270&&y<330)||(y>=130&&y<=170)||(y>=0&&y<=20))&&((x>=40&&x<=130)||(x>=190&&x<=280)||(x>=340&&x<=430)||(x>=490&&x<=580))){
       m=NM2.iMage4.getX()-100;//for first bomb
       n=NM2.iMage4.getY();
       NM2.iMage4.setX(NM2.initialbomb1x);
        NM2.iMage4.setY(NM2.initialbomb1y);

        NM2.fireimage4.setX(m);
        NM2.fireimage4.setY(n);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
        m=NM2.initialfirex;
        n=NM2.initialfirey;
        NM2.fireimage4.setX(m);
        NM2.fireimage4.setY(n);
     
       NM2.is_bomb_set_fourth_bomb=0;
   }else if((y==600)&&((x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490))){
       m=NM2.iMage4.getX()-100;// 3rd bomb
       n=NM2.iMage4.getY();
       o=NM2.iMage4.getX();//for bomb
       p=NM2.iMage4.getY()-157;
         NM2.iMage4.setX(NM2.initialbomb1x);
        NM2.iMage4.setY(NM2.initialbomb1y);
         NM2.fireimage4.setX(m);
         NM2.fireimage4.setY(n);
         NM2.ullomboimage4.setX(o);
         NM2.ullomboimage4.setY(p);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM2.fireimage4.getX()+changefirex1<=thismanx1)&&(NM2.fireimage4.getX()+changefirex2>=thismanx2)&&(NM2.fireimage4.getY()+changefirey1<=thismany1)&&(NM2.fireimage4.getY()+changefirey2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                  
                } 
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
           m=NM2.initialfirex;
        n=NM2.initialfirex;
        o=NM2.initialfirex;
        p=NM2.initialfirex;
           NM2.fireimage4.setX(m);
       NM2.fireimage4.setY(n);
         NM2.ullomboimage4.setX(o);
       NM2.ullomboimage4.setY(p);
     
          NM2.is_bomb_set_fourth_bomb=0;
   }else if(((y>=470&&y<=580)||(y>=330&&y<=420)||(y>=180&&y<=270)||(y>=30&&y<=120))&&((x>0&&x<40)||(x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490)||(x>580&&x<=600))){//commonfifth
       o=NM2.iMage4.getX()+10;//for fifth bomb
       p=NM2.iMage4.getY()-70;
       NM2.iMage4.setX(NM2.initialbomb1x);
        NM2.iMage4.setY(NM2.initialbomb1y);
        NM2.ullomboimage4.setX(o);
        NM2.ullomboimage4.setY(p);
        double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                
                if(Reader.flag&&(NM2.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   
                   Reader.flag=false;
                    new collidethread();
                } 
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
        o=NM2.initialfirex;
        p=NM2.initialfirey;
        NM2.ullomboimage4.setX(o);
       NM2.ullomboimage4.setY(p);
       NM2.is_bomb_set_fourth_bomb=0;
   }else if(((y<470&&y>420)||(y>270&&y<330)||(y>=130&&y<=170))&&(x>=0&&x<40)){
       m=NM2.iMage4.getX();//for sixth bomb
       n=NM2.iMage4.getY()-10;
         o=NM2.iMage4.getX()+10;//for bomb
       p=NM2.iMage4.getY()-70;
         NM2.iMage4.setX(NM2.initialbomb1x);
        NM2.iMage4.setY(NM2.initialbomb1y);
         NM2.fireimage4.setX(m);
         NM2.fireimage4.setY(n);
         NM2.ullomboimage4.setX(o);
         NM2.ullomboimage4.setY(p);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM2.fireimage4.getX()+changefirex1<=thismanx1)&&(NM2.fireimage4.getX()+changefirex2>=thismanx2)&&(NM2.fireimage4.getY()+changefirey1<=thismany1)&&(NM2.fireimage4.getY()+changefirey2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                  
                } 
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
           m=NM2.initialfirex;
        n=NM2.initialfirex;
        o=NM2.initialfirex;
        p=NM2.initialfirex;
           NM2.fireimage4.setX(m);
     NM2.fireimage4.setY(n);
         NM2.ullomboimage4.setX(o);
       NM2.ullomboimage4.setY(p);
   
          NM2.is_bomb_set_fourth_bomb=0;
   }
       else if(((y>420&&y<470)||(y>270&&y<330)||(y>=130&&y<=170))&&(x>580&&x<=600)){
       m=NM2.iMage4.getX()-200;// 3rd bomb
       n=NM2.iMage4.getY();
         o=NM2.iMage4.getX()+10;//for bomb
       p=NM2.iMage4.getY()-79;
         NM2.iMage4.setX(NM2.initialbomb1x);
        NM2.iMage4.setY(NM2.initialbomb1y);
         NM2.fireimage4.setX(m);
         NM2.fireimage4.setY(n);
         NM2.ullomboimage4.setX(o);
         NM2.ullomboimage4.setY(p);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM2.fireimage4.getX()+changefirex1<=thismanx1)&&(NM2.fireimage4.getX()+changefirex2>=thismanx2)&&(NM2.fireimage4.getY()+changefirey1<=thismany1)&&(NM2.fireimage4.getY()+changefirey2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                  
                } 
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
    
          m=NM2.initialfirex;
        n=NM2.initialfirex;
        o=NM2.initialfirex;
        p=NM2.initialfirex;
           NM2.fireimage4.setX(m);
       NM2.fireimage4.setY(n);
         NM2.ullomboimage4.setX(o);
       NM2.ullomboimage4.setY(p);
          NM2.is_bomb_set_fourth_bomb=0;
   }else if(((y>420&&y<470)||(y>270&&y<330)||(y>=130&&y<=170))&&((x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490))){
       m=NM2.iMage4.getX()-100;// 3rd bomb
       n=NM2.iMage4.getY();
         o=NM2.iMage4.getX()+10;//for bomb
       p=NM2.iMage4.getY()-79;
         NM2.iMage4.setX(NM2.initialbomb1x);
        NM2.iMage4.setY(NM2.initialbomb1y);
         NM2.fireimage4.setX(m);
         NM2.fireimage4.setY(n);
         NM2.ullomboimage4.setX(o);
         NM2.ullomboimage4.setY(p);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM2.fireimage4.getX()+changefirex1<=thismanx1)&&(NM2.fireimage4.getX()+changefirex2>=thismanx2)&&(NM2.fireimage4.getY()+changefirey1<=thismany1)&&(NM2.fireimage4.getY()+changefirey2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                  
                } 
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
      
         m=NM2.initialfirex;
        n=NM2.initialfirex;
        o=NM2.initialfirex;
       p=NM2.initialfirex;
           NM2.fireimage4.setX(m);
       NM2.fireimage4.setY(n);
         NM2.ullomboimage4.setX(o);
       NM2.ullomboimage4.setY(p);

          NM2.is_bomb_set_fourth_bomb=0;
   }else if((y>=0&&y<=20)&&((x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490))){
       m=NM2.iMage4.getX()-100;// 3rd bomb
       n=NM2.iMage4.getY();
         o=NM2.iMage4.getX();//for bomb
       p=NM2.iMage4.getY();
         NM2.iMage4.setX(NM2.initialbomb1x);
        NM2.iMage4.setY(NM2.initialbomb1y);
         NM2.fireimage4.setX(m);
         NM2.fireimage4.setY(n);
         NM2.ullomboimage4.setX(o);
         NM2.ullomboimage4.setY(p);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM2.fireimage4.getX()+changefirex1<=thismanx1)&&(NM2.fireimage4.getX()+changefirex2>=thismanx2)&&(NM2.fireimage4.getY()+changefirey1<=thismany1)&&(NM2.fireimage4.getY()+changefirey2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                  
                } 
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
     
         m=NM2.initialfirex;
        n=NM2.initialfirex;
        o=NM2.initialfirex;
        p=NM2.initialfirex;
           NM2.fireimage4.setX(m);
       NM2.fireimage4.setY(n);
         NM2.ullomboimage4.setX(o);
       NM2.ullomboimage4.setY(p);
          NM2.is_bomb_set_fourth_bomb=0;
   }else if((x>=0&&x<40)&&(y<=20&&y>=0)){
         m=NM2.iMage4.getX();//for bomb
       n=NM2.iMage4.getY()-10;
         o=NM2.iMage4.getX();//for bomb
       p=NM2.iMage4.getY();
       NM2.iMage4.setX(NM2.initialbomb1x);
        NM2.iMage4.setY(NM2.initialbomb1y);

         NM2.fireimage4.setX(m);
         NM2.fireimage4.setY(n);
         NM2.ullomboimage4.setX(o);
         NM2.ullomboimage4.setY(p);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM2.fireimage4.getX()+changefirex1<=thismanx1)&&(NM2.fireimage4.getX()+changefirex2>=thismanx2)&&(NM2.fireimage4.getY()+changefirey1<=thismany1)&&(NM2.fireimage4.getY()+changefirey2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                  
                } 
      
      //}
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }

    
         m=NM2.initialfirex;
        n=NM2.initialfirex;
        o=NM2.initialfirex;
        p=NM2.initialfirex;
           NM2.fireimage4.setX(m);
       NM2.fireimage4.setY(n);
         NM2.ullomboimage4.setX(o);
       NM2.ullomboimage4.setY(p);
          NM2.is_bomb_set_fourth_bomb=0;
   }else if((x>580&&x<=600)&&(y<=20&&y>=0)){
        
       m=NM2.iMage4.getX()-200;//for bomb fourthbomb
       n=NM2.iMage4.getY();
         o=NM2.iMage4.getX()+10;//for bomb
       p=NM2.iMage4.getY();
        NM2.iMage4.setX(NM2.initialbomb1x);
       NM2.iMage4.setY(NM2.initialbomb1y);

         NM2.fireimage4.setX(m);
         NM2.fireimage4.setY(n);
         NM2.ullomboimage4.setX(o);
         NM2.ullomboimage4.setY(p);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage4.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage4.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage4.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage4.getY()+changeullomboy2>=thismany2)){
                   
                   Reader.flag=false;
                    new collidethread();
                } else if(Reader.flag&&(NM2.fireimage4.getX()+changefirex1<=thismanx1)&&(NM2.fireimage4.getX()+changefirex2>=thismanx2)&&(NM2.fireimage4.getY()+changefirey1<=thismany1)&&(NM2.fireimage4.getY()+changefirey2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                  
                } 
      
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }

    
         m=NM2.initialfirex;
        n=NM2.initialfirex;
        o=NM2.initialfirex;
        p=NM2.initialfirex;
           NM2.fireimage4.setX(m);
       NM2.fireimage4.setY(n);
         NM2.ullomboimage4.setX(o);
       NM2.ullomboimage4.setY(p);
          NM2.is_bomb_set_fourth_bomb=0;
   }
   }
    
}

    


    

