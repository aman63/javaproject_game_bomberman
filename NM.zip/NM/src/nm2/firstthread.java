/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nm2;

import nm2.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import static nm2.NM2.a;
import static nm2.NM2.b;
import static nm2.NM2.c;
import static nm2.NM2.d;



/**
 *
 * @author User
 */
public class firstthread implements Runnable{
    
    
    
   public void action(){
       
   }
    @Override
    public void run(){ 
       System.out.println("ok");
        
        try{
          
            Thread.sleep(5000);
 
        }catch(Exception e){
            System.out.println("interrupted");
        }
       double x=NM2.iMage.getX();
       double y=NM2.iMage.getY();
        
       if((x>580&&x<=600)&&(y<=600&&y>580)){
        
       a=NM2.iMage.getX()-200;//for bomb fourthbomb
       b=NM2.iMage.getY();
       c=NM2.iMage.getX()+10;//for bomb
       d=NM2.iMage.getY()-157;
        NM2.iMage.setX(NM2.initialbomb1x);
        NM2.iMage.setY(NM2.initialbomb1y);

         NM2.fireimage1.setX(a);
         NM2.fireimage1.setY(b);
         NM2.ullomboimage.setX(c);
         NM2.ullomboimage.setY(d);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                    System.out.println("hh");
                } else if(Reader.flag&&(NM2.fireimage1.getX()+changefirex1<=thismanx1)&&(NM2.fireimage1.getX()+changefirex2>=thismanx2)&&(NM2.fireimage1.getY()+changefirey1<=thismany1)&&(NM2.fireimage1.getY()+changefirey2>=thismany2)){
                    
                   
                   Reader.flag=false;
                    new collidethread();
                  
                } 
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
        a=NM2.initialfirex;
        b=NM2.initialfirex;
        c=NM2.initialfirex;
        d=NM2.initialfirex;
           NM2.fireimage1.setX(a);
       NM2.fireimage1.setY(b);
         NM2.ullomboimage.setX(c);
       NM2.ullomboimage.setY(d);
          NM2.is_bomb_set_first_bomb=0;
 
       }else if((x>=0&&x<40)&&(y<=600&&y>580)){
         a=NM2.iMage.getX();//for bomb
       b=NM2.iMage.getY();
         c=NM2.iMage.getX();//for bomb
       d=NM2.iMage.getY()-157;
       NM2.iMage.setX(NM2.initialbomb1x);
        NM2.iMage.setY(NM2.initialbomb1y);

         NM2.fireimage1.setX(a);
         NM2.fireimage1.setY(b);
         NM2.ullomboimage.setX(c);
         NM2.ullomboimage.setY(d);
          double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                    System.out.println("hh");
                } else if(Reader.flag&&(NM2.fireimage1.getX()+changefirex1<=thismanx1)&&(NM2.fireimage1.getX()+changefirex2>=thismanx2)&&(NM2.fireimage1.getY()+changefirey1<=thismany1)&&(NM2.fireimage1.getY()+changefirey2>=thismany2)){
                    
                   
                   Reader.flag=false;
                    new collidethread();
                  
                } 
      //}
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
          a=NM2.initialfirex;
        b=NM2.initialfirex;
        c=NM2.initialfirex;
        d=NM2.initialfirex;
           NM2.fireimage1.setX(a);
       NM2.fireimage1.setY(b);
         NM2.ullomboimage.setX(c);
       NM2.ullomboimage.setY(d);
          NM2.is_bomb_set_first_bomb=0;
    
    }else if((y==600||(y>420&&y<470)||(y>270&&y<330)||(y>=130&&y<=170)||(y>=0&&y<=20))&&((x>=40&&x<=130)||(x>=190&&x<=280)||(x>=340&&x<=430)||(x>=490&&x<=580))){
       a=NM2.iMage.getX()-100;//for first bomb
       b=NM2.iMage.getY();
       NM2.iMage.setX(NM2.initialbomb1x);
        NM2.iMage.setY(NM2.initialbomb1y);

        NM2.fireimage1.setX(a);
        NM2.fireimage1.setY(b);
       
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
               
                 if(Reader.flag&&(NM2.fireimage1.getX()+changefirex1<=thismanx1)&&(NM2.fireimage1.getX()+changefirex2>=thismanx2)&&(NM2.fireimage1.getY()+changefirey1<=thismany1)&&(NM2.fireimage1.getY()+changefirey2>=thismany2)){
                    
                   
                   Reader.flag=false;
                    new collidethread();
                  
                } 
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
        a=NM2.initialfirex;
        b=NM2.initialfirey;
        NM2.fireimage1.setX(a);
        NM2.fireimage1.setY(b);
     
       NM2.is_bomb_set_first_bomb=0;
   }else if((y==600)&&((x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490))){
       a=NM2.iMage.getX()-100;// 3rd bomb
       b=NM2.iMage.getY();
       c=NM2.iMage.getX();//for bomb
       d=NM2.iMage.getY()-157;
         NM2.iMage.setX(NM2.initialbomb1x);
        NM2.iMage.setY(NM2.initialbomb1y);
         NM2.fireimage1.setX(a);
         NM2.fireimage1.setY(b);
         NM2.ullomboimage.setX(c);
         NM2.ullomboimage.setY(d);
          double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                    System.out.println("hh");
                } else if(Reader.flag&&(NM2.fireimage1.getX()+changefirex1<=thismanx1)&&(NM2.fireimage1.getX()+changefirex2>=thismanx2)&&(NM2.fireimage1.getY()+changefirey1<=thismany1)&&(NM2.fireimage1.getY()+changefirey2>=thismany2)){
                    
                   
                   Reader.flag=false;
                    new collidethread();
                  
                } 
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
           a=NM2.initialfirex;
        b=NM2.initialfirex;
        c=NM2.initialfirex;
        d=NM2.initialfirex;
           NM2.fireimage1.setX(a);
       NM2.fireimage1.setY(b);
         NM2.ullomboimage.setX(c);
       NM2.ullomboimage.setY(d);
     
          NM2.is_bomb_set_first_bomb=0;
   }else if(((y>=470&&y<=580)||(y>=330&&y<=420)||(y>=180&&y<=270)||(y>=30&&y<=120))&&((x>0&&x<40)||(x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490)||(x>580&&x<=600))){//commonfifth
       c=NM2.iMage.getX()+10;//for fifth bomb
       d=NM2.iMage.getY()-70;
       NM2.iMage.setX(NM2.initialbomb1x);
        NM2.iMage.setY(NM2.initialbomb1y);
        NM2.ullomboimage.setX(c);
        NM2.ullomboimage.setY(d);
         double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
              
                if(Reader.flag&&(NM2.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                    System.out.println("hh");
                } 
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
        c=NM2.initialfirex;
        d=NM2.initialfirey;
        NM2.ullomboimage.setX(c);
       NM2.ullomboimage.setY(d);
       NM2.is_bomb_set_first_bomb=0;
   }else if(((y<470&&y>420)||(y>270&&y<330)||(y>=130&&y<=170))&&(x>=0&&x<40)){
       a=NM2.iMage.getX();//for sixth bomb
       b=NM2.iMage.getY()-10;
         c=NM2.iMage.getX()+10;//for bomb
       d=NM2.iMage.getY()-70;
         NM2.iMage.setX(NM2.initialbomb1x);
        NM2.iMage.setY(NM2.initialbomb1y);
         NM2.fireimage1.setX(a);
         NM2.fireimage1.setY(b);
         NM2.ullomboimage.setX(c);
         NM2.ullomboimage.setY(d);
          double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                    System.out.println("hh");
                } else if(Reader.flag&&(NM2.fireimage1.getX()+changefirex1<=thismanx1)&&(NM2.fireimage1.getX()+changefirex2>=thismanx2)&&(NM2.fireimage1.getY()+changefirey1<=thismany1)&&(NM2.fireimage1.getY()+changefirey2>=thismany2)){
                    
                   
                   Reader.flag=false;
                    new collidethread();
                  
                } 
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
           a=NM2.initialfirex;
        b=NM2.initialfirex;
        c=NM2.initialfirex;
        d=NM2.initialfirex;
           NM2.fireimage1.setX(a);
       NM2.fireimage1.setY(b);
         NM2.ullomboimage.setX(c);
       NM2.ullomboimage.setY(d);
   
          NM2.is_bomb_set_first_bomb=0;
   }
       else if(((y>420&&y<470)||(y>270&&y<330)||(y>=130&&y<=170))&&(x>580&&x<=600)){
       a=NM2.iMage.getX()-200;// 3rd bomb
       b=NM2.iMage.getY();
         c=NM2.iMage.getX()+10;//for bomb
       d=NM2.iMage.getY()-79;
         NM2.iMage.setX(NM2.initialbomb1x);
        NM2.iMage.setY(NM2.initialbomb1y);
         NM2.fireimage1.setX(a);
         NM2.fireimage1.setY(b);
         NM2.ullomboimage.setX(c);
         NM2.ullomboimage.setY(d);
          double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                    System.out.println("hh");
                } else if(Reader.flag&&(NM2.fireimage1.getX()+changefirex1<=thismanx1)&&(NM2.fireimage1.getX()+changefirex2>=thismanx2)&&(NM2.fireimage1.getY()+changefirey1<=thismany1)&&(NM2.fireimage1.getY()+changefirey2>=thismany2)){
                    
                   
                   Reader.flag=false;
                    new collidethread();
                  
                } 
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
    
          a=NM2.initialfirex;
        b=NM2.initialfirex;
        c=NM2.initialfirex;
        d=NM2.initialfirex;
           NM2.fireimage1.setX(a);
       NM2.fireimage1.setY(b);
         NM2.ullomboimage.setX(c);
       NM2.ullomboimage.setY(d);
          NM2.is_bomb_set_first_bomb=0;
   }else if(((y>420&&y<470)||(y>270&&y<330)||(y>=130&&y<=170))&&((x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490))){
       a=NM2.iMage.getX()-100;// 3rd bomb
       b=NM2.iMage.getY();
         c=NM2.iMage.getX()+10;//for bomb
       d=NM2.iMage.getY()-79;
         NM2.iMage.setX(NM2.initialbomb1x);
        NM2.iMage.setY(NM2.initialbomb1y);
         NM2.fireimage1.setX(a);
         NM2.fireimage1.setY(b);
         NM2.ullomboimage.setX(c);
         NM2.ullomboimage.setY(d);
          double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                    System.out.println("hh");
                } else if(Reader.flag&&(NM2.fireimage1.getX()+changefirex1<=thismanx1)&&(NM2.fireimage1.getX()+changefirex2>=thismanx2)&&(NM2.fireimage1.getY()+changefirey1<=thismany1)&&(NM2.fireimage1.getY()+changefirey2>=thismany2)){
                    
                   
                   Reader.flag=false;
                    new collidethread();
                  
                } 
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
      
         a=NM2.initialfirex;
        b=NM2.initialfirex;
        c=NM2.initialfirex;
        d=NM2.initialfirex;
           NM2.fireimage1.setX(a);
       NM2.fireimage1.setY(b);
         NM2.ullomboimage.setX(c);
       NM2.ullomboimage.setY(d);

          NM2.is_bomb_set_first_bomb=0;
   }else if((y>=0&&y<=20)&&((x>130&&x<190)||(x>280&&x<340)||(x>430&&x<490))){
       a=NM2.iMage.getX()-100;// 3rd bomb
       b=NM2.iMage.getY();
         c=NM2.iMage.getX();//for bomb
       d=NM2.iMage.getY();
         NM2.iMage.setX(NM2.initialbomb1x);
        NM2.iMage.setY(NM2.initialbomb1y);
         NM2.fireimage1.setX(a);
         NM2.fireimage1.setY(b);
         NM2.ullomboimage.setX(c);
         NM2.ullomboimage.setY(d);
          double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                    System.out.println("hh");
                } else if(Reader.flag&&(NM2.fireimage1.getX()+changefirex1<=thismanx1)&&(NM2.fireimage1.getX()+changefirex2>=thismanx2)&&(NM2.fireimage1.getY()+changefirey1<=thismany1)&&(NM2.fireimage1.getY()+changefirey2>=thismany2)){
                    
                   
                   Reader.flag=false;
                    new collidethread();
                  
                } 
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }
     
         a=NM2.initialfirex;
        b=NM2.initialfirex;
        c=NM2.initialfirex;
        d=NM2.initialfirex;
           NM2.fireimage1.setX(a);
       NM2.fireimage1.setY(b);
         NM2.ullomboimage.setX(c);
       NM2.ullomboimage.setY(d);
          NM2.is_bomb_set_first_bomb=0;
   }else if((x>=0&&x<40)&&(y<=20&&y>=0)){
         a=NM2.iMage.getX();//for bomb
       b=NM2.iMage.getY()-10;
         c=NM2.iMage.getX();//for bomb
       d=NM2.iMage.getY();
       NM2.iMage.setX(NM2.initialbomb1x);
        NM2.iMage.setY(NM2.initialbomb1y);

         NM2.fireimage1.setX(a);
         NM2.fireimage1.setY(b);
         NM2.ullomboimage.setX(c);
         NM2.ullomboimage.setY(d);
          double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                    System.out.println("hh");
                } else if(Reader.flag&&(NM2.fireimage1.getX()+changefirex1<=thismanx1)&&(NM2.fireimage1.getX()+changefirex2>=thismanx2)&&(NM2.fireimage1.getY()+changefirey1<=thismany1)&&(NM2.fireimage1.getY()+changefirey2>=thismany2)){
                    
                   
                   Reader.flag=false;
                    new collidethread();
                  
                } 
      //}
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }

    
         a=NM2.initialfirex;
        b=NM2.initialfirex;
        c=NM2.initialfirex;
        d=NM2.initialfirex;
           NM2.fireimage1.setX(a);
       NM2.fireimage1.setY(b);
         NM2.ullomboimage.setX(c);
       NM2.ullomboimage.setY(d);
          NM2.is_bomb_set_first_bomb=0;
   }else if((x>580&&x<=600)&&(y<=20&&y>=0)){
        
       a=NM2.iMage.getX()-200;//for bomb fourthbomb
       b=NM2.iMage.getY();
         c=NM2.iMage.getX()+10;//for bomb
       d=NM2.iMage.getY();
        NM2.iMage.setX(NM2.initialbomb1x);
        NM2.iMage.setY(NM2.initialbomb1y);

         NM2.fireimage1.setX(a);
         NM2.fireimage1.setY(b);
         NM2.ullomboimage.setX(c);
         NM2.ullomboimage.setY(d);
          double changeullombox1=0;
                  double changeullombox2=46;
                    double changeullomboy1=0;
                      double changeullomboy2=217;
          double thismanx1=NM2.image.getX();
                double thismanx2=NM2.image.getX()+60; 
                double thismany1=NM2.image.getY();
                double thismany2=NM2.image.getY()+60;
                double changefirex1=0;
                double changefirex2=260;
                double changefirey1=0;
                double changefirey2=70;
                if(Reader.flag&&(NM2.ullomboimage.getX()+changeullombox1<=thismanx1)&&(NM2.ullomboimage.getX()+changeullombox2>=thismanx2)&&(NM2.ullomboimage.getY()+changeullomboy1<=thismany1)&&(NM2.ullomboimage.getY()+changeullomboy2>=thismany2)){
                   Reader.flag=false;
                    new collidethread();
                    System.out.println("hh");
                } else if(Reader.flag&&(NM2.fireimage1.getX()+changefirex1<=thismanx1)&&(NM2.fireimage1.getX()+changefirex2>=thismanx2)&&(NM2.fireimage1.getY()+changefirey1<=thismany1)&&(NM2.fireimage1.getY()+changefirey2>=thismany2)){
                    
                   
                   Reader.flag=false;
                    new collidethread();
                  
                } 
      
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(firstthread.class.getName()).log(Level.SEVERE, null, ex);
        }

    
         a=NM2.initialfirex;
        b=NM2.initialfirex;
        c=NM2.initialfirex;
        d=NM2.initialfirex;
           NM2.fireimage1.setX(a);
       NM2.fireimage1.setY(b);
         NM2.ullomboimage.setX(c);
       NM2.ullomboimage.setY(d);
          NM2.is_bomb_set_first_bomb=0;
   }
   }
}

