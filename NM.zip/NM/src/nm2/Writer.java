/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nm2;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import util.data;
import util.networkutil;

/**
 *
 * @author User
 */
public class Writer implements Runnable{
    
    public networkutil connection;
    
    public Writer(networkutil nc){
        connection = nc;
    }

    @Override
    public void run() {
      //  Scanner in =new Scanner(System.in);
       
       
        while(true){
          
            try{
                 Thread.sleep(100);
                 //   System.out.println("written");
               
            
                 data d=new data(nm2.NM2.image.getX(),nm2.NM2.image.getY(),nm2.NM2.iMage.getX(),nm2.NM2.iMage.getY(),nm2.NM2.iMage2.getX(),nm2.NM2.iMage2.getY(),nm2.NM2.iMage3.getX(),nm2.NM2.iMage3.getY(),nm2.NM2.iMage4.getX(),nm2.NM2.iMage4.getY(),nm2.NM2.ullomboimage.getX(),nm2.NM2.ullomboimage.getY(),nm2.NM2.fireimage1.getX(),nm2.NM2.fireimage1.getY(),nm2.NM2.ullomboimage2.getX(),nm2.NM2.ullomboimage2.getY(),nm2.NM2.fireimage2.getX(),nm2.NM2.fireimage2.getY(),nm2.NM2.ullomboimage3.getX(),nm2.NM2.ullomboimage3.getY(),nm2.NM2.fireimage3.getX(),nm2.NM2.fireimage3.getY(),nm2.NM2.ullomboimage4.getX(),nm2.NM2.ullomboimage4.getY(),nm2.NM2.fireimage4.getX(),nm2.NM2.fireimage4.getY(),nm2.NM2.number_of_lives_left);//,nm.NM.iMage2.getX(),nm.NM.iMage2.getY(),nm.NM.iMage3.getX(),nm.NM.iMage3.getY(),nm.NM.iMage4.getX(),nm.NM.iMage4.getY()); 
              
                connection.write(d);
             
                

           
            }catch(Exception e){
               // System.out.println("ok");
            }
        }
    }
    
}
