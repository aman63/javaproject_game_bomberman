    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nm2;


import Client.ClientMain;
import Client.ClientMain1;
import java.io.IOException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import nm2.firstthread;
import nm2.fourththread;
import nm2.secondthread;
import nm2.thirdthread;

/**
 *
 * @author User
 */
public class NM2 extends Application {
    
   
      static public double a=2000;
    static public double b=2000;
    static public double c=2000;
    static public double d=2000;
    
    static public double e=2000;
    static public double f=2000;
    static public double g=2000;
    static public double h=2000;
    
    static public double i=2000;
    static public double j=2000;
    static public double k=2000;
    static public double l=2000;
    
     static public double m=2000;
    static public double n=2000;
    static public double o=2000;
    static public double p=2000;
    static int flag=0;
    static int initialbomb1x=2000;
    static int initialbomb1y=2000;
    
     public static ImageView life1=new ImageView("img/green_life.png");
        public static ImageView life2=new ImageView("img/green_life.png");
         public static ImageView life3=new ImageView("img/green_life.png");
          public static ImageView life4=new ImageView("img/green_life.png");
            public static ImageView life5=new ImageView("img/green_life.png");
               public static ImageView red_life1=new ImageView("img/red_life.png");
        public static ImageView red_life2=new ImageView("img/red_life.png");
         public static ImageView red_life3=new ImageView("img/red_life.png");
          public static ImageView red_life4=new ImageView("img/red_life.png");
            public static ImageView red_life5=new ImageView("img/red_life.png");
             public static int number_of_lives_left=5;
            
          
       public static ImageView secondplayer_life1=new ImageView("img/green_life.png");
        public static ImageView secondplayer_life2=new ImageView("img/green_life.png");
         public static ImageView secondplayer_life3=new ImageView("img/green_life.png");
          public static ImageView secondplayer_life4=new ImageView("img/green_life.png");
            public static ImageView secondplayer_life5=new ImageView("img/green_life.png");
            public static ImageView red_secondplayer_life1=new ImageView("img/red_life.png");
        public static ImageView red_secondplayer_life2=new ImageView("img/red_life.png");
         public static ImageView red_secondplayer_life3=new ImageView("img/red_life.png");
          public static ImageView red_secondplayer_life4=new ImageView("img/red_life.png");
            public static ImageView red_secondplayer_life5=new ImageView("img/red_life.png");
            public static int secondplayer_number_of_lives_left=5;
           public static int prev_secondplayer_number_of_lives_left=5;
           
                public static ImageView ducks1=new ImageView("img/duck_image.png");
       public static ImageView ducks2=new ImageView("img/duck_image.png");
       public static ImageView ducks3=new ImageView("img/duck_image.png");
        public static ImageView ducks4=new ImageView("img/duck_image.png");
   public static ImageView ducks5=new ImageView("img/duck_image.png");
       
             public static ColorAdjust colorAdjust=new ColorAdjust();
            
    public static ImageView ullomboimage=new ImageView("img/longsfire.png");
    public static ImageView fireimage1=new ImageView("img/fires.png");
    
      public static ImageView ullomboimage2=new ImageView("img/lonsfire2.png");
    public static ImageView fireimage2=new ImageView("img/fires2.png");
    
      public static ImageView ullomboimage3=new ImageView("img/longsfire3.png");
      public static ImageView fireimage3=new ImageView("img/fires3.png");
      
       public static ImageView ullomboimage4=new ImageView("img/longsfire4.png");
      public static ImageView fireimage4=new ImageView("img/fires4.png");
      
        public static ImageView secondplayer_ullomboimage1=new ImageView("img/secondplayer_longsfire.png");
    public static ImageView secondplayer_fireimage1=new ImageView("img/secondplayer_fire.png");
    
      public static ImageView secondplayer_ullomboimage2=new ImageView("img/secondplayer_longsfire.png");
    public static ImageView secondplayer_fireimage2=new ImageView("img/secondplayer_fire.png");
    
      public static ImageView secondplayer_ullomboimage3=new ImageView("img/secondplayer_longsfire.png");
      public static ImageView secondplayer_fireimage3=new ImageView("img/secondplayer_fire.png");
      
       public static ImageView secondplayer_ullomboimage4=new ImageView("img/secondplayer_longsfire.png");
      public static ImageView secondplayer_fireimage4=new ImageView("img/secondplayer_fire.png");
      
    public static ImageView iMage=new ImageView("img/Bomb.png");
      public static ImageView iMage2=new ImageView("img/Bomb2.png");
       public static ImageView iMage3=new ImageView("img/Bomb3.png");
         public static ImageView iMage4=new ImageView("img/Bomb4.png");
         public static ImageView secondplayer_iMage1=new ImageView("img/secondplayer_bomb.png");
           public static ImageView secondplayer_iMage2=new ImageView("img/secondplayer_bomb.png");
             public static ImageView secondplayer_iMage3=new ImageView("img/secondplayer_bomb.png");
               public static ImageView secondplayer_iMage4=new ImageView("img/secondplayer_bomb.png");
                 public static ImageView life22=new ImageView("img/secondlife.png");
                  public static ImageView life11=new ImageView("img/life1.png");
                 public static ImageView gameover=new ImageView("img/Game_over.jpg");    
           public static ImageView winner=new ImageView("img/winner.jpg");  
       
    public static int is_bomb_set_first_bomb =0;
    public static int is_bomb_set_second_bomb=0;
     public static int is_bomb_set_third_bomb=0;
      public static int is_bomb_set_fourth_bomb=0;
     
    public static Group root;
    public static ImageView image=new ImageView("img/bomberman.png");
    public static ImageView image2=new ImageView("img/bombermansecondplayer.png");
   static int initialfirex=2000,initialfirey=2000;
  
    @Override
    public void start(Stage primaryStage) throws IOException {
          colorAdjust.setHue(60);
          colorAdjust.setSaturation(.02);
           colorAdjust.setBrightness(.22);
               
         ullomboimage.setX(initialfirex);
         ullomboimage.setY(initialfirey);
           ullomboimage2.setX(initialfirex);
         ullomboimage2.setY(initialfirey);
          ullomboimage3.setX(initialfirex);
         ullomboimage3.setY(initialfirey);
           ullomboimage4.setX(initialfirex);
         ullomboimage4.setY(initialfirey);
         secondplayer_ullomboimage1.setX(initialfirex);
         secondplayer_ullomboimage1.setY(initialfirey);
           secondplayer_ullomboimage2.setX(initialfirex);
         secondplayer_ullomboimage2.setY(initialfirey);
          secondplayer_ullomboimage3.setX(initialfirex);
         secondplayer_ullomboimage3.setY(initialfirey);
           secondplayer_ullomboimage4.setX(initialfirex);
         secondplayer_ullomboimage4.setY(initialfirey);
         
         iMage.setX(initialbomb1x);
         iMage.setY(initialbomb1y);
         iMage2.setX(initialbomb1x);
         iMage2.setY(initialbomb1y);
          iMage3.setX(initialbomb1x);
         iMage3.setY(initialbomb1y);
           iMage4.setX(initialbomb1x);
         iMage4.setY(initialbomb1y);
            secondplayer_iMage1.setX(initialbomb1x);
         secondplayer_iMage1.setY(initialbomb1y);
         secondplayer_iMage2.setX(initialbomb1x);
         secondplayer_iMage2.setY(initialbomb1y);
          secondplayer_iMage3.setX(initialbomb1x);
         secondplayer_iMage3.setY(initialbomb1y);
           secondplayer_iMage4.setX(initialbomb1x);
         secondplayer_iMage4.setY(initialbomb1y);
      
       image.setX(400);
       image.setY(600);
       image2.setX(2000);
       image2.setY(2000);
       
     Parent Root=FXMLLoader.load(getClass().getResource("/nm2/firststage.fxml"));
        root=new Group();
        root.getChildren().add(Root);
         root.getChildren().add(ducks1);
          root.getChildren().add(ducks2);
           root.getChildren().add(ducks3);
           root.getChildren().add(ducks4);
              root.getChildren().add(ducks5);
        root.getChildren().add(image);
        root.getChildren().add(image2);
        
            root.getChildren().add(red_life1);
          root.getChildren().add(red_life2);
          root.getChildren().add(red_life3);
          root.getChildren().add(red_life4);
          root.getChildren().add(red_life5);
          root.getChildren().add(red_secondplayer_life1);
          root.getChildren().add(red_secondplayer_life2);
          root.getChildren().add(red_secondplayer_life3);
          root.getChildren().add(red_secondplayer_life4);
          root.getChildren().add(red_secondplayer_life5);
          root.getChildren().add(life1);
          root.getChildren().add(life2);
          root.getChildren().add(life3);
          root.getChildren().add(life4);
          root.getChildren().add(life5);
          root.getChildren().add(secondplayer_life1);
          root.getChildren().add(secondplayer_life2);
          root.getChildren().add(secondplayer_life3);
          root.getChildren().add(secondplayer_life4);
          root.getChildren().add(secondplayer_life5);
          root.getChildren().add(life22);
              life22.setX(350);
          life22.setY(700);
          root.getChildren().add(life11);
          life11.setX(5);
          life11.setY(700);
    
         int x_=65;
         red_life1.setX(x_);
         red_life1.setY(700);
         red_life2.setX(x_+50*1);
         red_life2.setY(700);
         red_life3.setX(x_+50*2);
         red_life3.setY(700);
         red_life4.setX(x_+50*3);
         red_life4.setY(700);
         red_life5.setX(x_+50*4);
         red_life5.setY(700);
         life1.setX(x_);
         life1.setY(700);
         life2.setX(x_+50*1);
         life2.setY(700);
         life3.setX(x_+50*2);
         life3.setY(700);
         life4.setX(x_+50*3);
         life4.setY(700);
         life5.setX(x_+50*4);
         life5.setY(700);
         x_=400;
         red_secondplayer_life1.setX(x_);
         red_secondplayer_life1.setY(700);
         red_secondplayer_life2.setX(x_+50*1);
         red_secondplayer_life2.setY(700);
         red_secondplayer_life3.setX(x_+50*2);
         red_secondplayer_life3.setY(700);
         red_secondplayer_life4.setX(x_+50*3);
         red_secondplayer_life4.setY(700);
         red_secondplayer_life5.setX(x_+50*4);
         red_secondplayer_life5.setY(700);
         secondplayer_life1.setX(x_);
         secondplayer_life1.setY(700);
         secondplayer_life2.setX(x_+50*1);
         secondplayer_life2.setY(700);
         secondplayer_life3.setX(x_+50*2);
         secondplayer_life3.setY(700);
         secondplayer_life4.setX(x_+50*3);
         secondplayer_life4.setY(700);
         secondplayer_life5.setX(x_+50*4);
         secondplayer_life5.setY(700);
        
        
   /*     fireimage1.setX(initialfirex);
        fireimage1.setY(initialfirey);
        fireimage2.setX(initialfirex);
        fireimage2.setY(initialfirey);
          fireimage3.setX(initialfirex);
        fireimage3.setY(initialfirey);
         fireimage4.setX(initialfirex);
        fireimage4.setY(initialfirey);*/
          secondplayer_fireimage1.setX(initialfirex);
        secondplayer_fireimage1.setY(initialfirey);
        secondplayer_fireimage2.setX(initialfirex);
        secondplayer_fireimage2.setY(initialfirey);
          secondplayer_fireimage3.setX(initialfirex);
        secondplayer_fireimage3.setY(initialfirey);
         secondplayer_fireimage4.setX(initialfirex);
        secondplayer_fireimage4.setY(initialfirey);
        
        root.getChildren().add(iMage);
         root.getChildren().add(fireimage1);
         root.getChildren().add(ullomboimage);
         
         root.getChildren().add(iMage2);
         root.getChildren().add(fireimage2);
         root.getChildren().add(ullomboimage2);
         
           root.getChildren().add(iMage3);
         root.getChildren().add(fireimage3);
         root.getChildren().add(ullomboimage3);
         
            root.getChildren().add(iMage4);
         root.getChildren().add(fireimage4);
         root.getChildren().add(ullomboimage4);
         
           root.getChildren().add(secondplayer_iMage1);
             root.getChildren().add(secondplayer_fireimage1);
         root.getChildren().add(secondplayer_ullomboimage1);
        
         root.getChildren().add(secondplayer_iMage2);
            root.getChildren().add(secondplayer_fireimage2);
         root.getChildren().add(secondplayer_ullomboimage2);
         
         root.getChildren().add(secondplayer_iMage3);
            root.getChildren().add(secondplayer_fireimage3);
         root.getChildren().add(secondplayer_ullomboimage3);
         
         root.getChildren().add(secondplayer_iMage4);
            root.getChildren().add(secondplayer_fireimage4);
         root.getChildren().add(secondplayer_ullomboimage4);
      
       
          root.getChildren().add(gameover);
            root.getChildren().add(winner);
          gameover.setX(2000);
          gameover.setY(2000);
            winner.setX(2000);
          winner.setY(2000);
        ducks1.setX(2000);
        ducks1.setY(2000);
        ducks2.setX(2000);
        ducks2.setY(2000);
        ducks3.setX(2000);
        ducks3.setY(2000);
          ducks4.setX(2000);
        ducks4.setY(2000);
            ducks5.setX(2000);
        ducks5.setY(2000);
     fireimage1.setX(initialfirex);
        fireimage1.setY(initialfirey);
        fireimage2.setX(initialfirex);
        fireimage2.setY(initialfirey);
          fireimage3.setX(initialfirex);
        fireimage3.setY(initialfirey);
         fireimage4.setX(initialfirex);
        fireimage4.setY(initialfirey);
        
        Scene scene = new Scene(root,675,800);
        
        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
         scene.setOnKeyTyped((KeyEvent event) -> {
            double x=image.getX();
            double y=image.getY();
            switch(event.getCharacter()){
                
                
                case "i":
                    if(y>=0&&y<=10){
                        break;
                    }
                    
                    else if(y>=150&&y<=160&&x>10&&x<150){
                        break;
                    }
                    else if(y>=150&&y<=160&&x>160&&x<300){
                        break;
                    }
                    else if(y>=150&&y<=160&&x>310&&x<450){
                        break;
                    }
                    else if(y>=150&&y<=160&&x>460&&x<600){
                        break;
                    }
                    
                    else if(y>=300&&y<=310&&x>10&&x<150){
                        break;
                    }
                    else if(y>=300&&y<=310&&x>160&&x<300){
                        break;
                    }
                    else if(y>=300&&y<=310&&x>310&&x<450){
                        break;
                    }
                    else if(y>=300&&y<=310&&x>460&&x<600){
                        break;
                    }
                    else if(y>=450&&y<=460&&x>10&&x<150){
                        break;
                    }
                    else if(y>=450&&y<=460&&x>160&&x<300){
                        break;
                    }
                    else if(y>=450&&y<=460&&x>310&&x<450){
                        break;
                    }
                    else if(y>=450&&y<=460&&x>460&&x<600){
                        break;
                    }
                    else if(y>=600&&y<=610&&x>10&&x<150){
                        break;
                    }
                    else if(y>=600&&y<=610&&x>160&&x<300){
                        break;
                    }
                    else if(y>=600&&y<=610&&x>310&&x<450){
                        break;
                    }
                    else if(y>=600&&y<=610&&x>460&&x<600){
                        break;
                    }
                    image.setY(image.getY()-10);
                  //  System.out.println(image.getX()+" "+image.getY());
                    break;
                case "k":
                    if(y>=0&&y<=10&&x>10&&x<150){
                        break;
                    }
                    else if(y>=0&&y<=10&&x>160&&x<300){
                        break;
                    }
                    else if(y>=0&&y<=10&&x>310&&x<450){
                        break;
                    }
                    else if(y>=0&&y<=10&&x>460&&x<600){
                        break;
                    }
                    
                    else if(y>=150&&y<=160&&x>10&&x<150){
                        break;
                    }
                    else if(y>=150&&y<=160&&x>160&&x<300){
                        break;
                    }
                    else if(y>=150&&y<=160&&x>310&&x<450){
                        break;
                    }
                    else if(y>=150&&y<=160&&x>460&&x<600){
                        break;
                    }
                    
                    else if(y>=300&&y<=310&&x>10&&x<150){
                        break;
                    }
                    else if(y>=300&&y<=310&&x>160&&x<300){
                        break;
                    }
                    else if(y>=300&&y<=310&&x>310&&x<450){
                        break;
                    }
                    else if(y>=300&&y<=310&&x>460&&x<600){
                        break;
                    }
                    else if(y>=450&&y<=460&&x>10&&x<150){
                        break;
                    }
                    else if(y>=450&&y<=460&&x>160&&x<300){
                        break;
                    }
                    else if(y>=450&&y<=460&&x>310&&x<450){
                        break;
                    }
                    else if(y>=450&&y<=460&&x>460&&x<600){
                        break;
                    }
                    else if(y>=600&&y<=610){
                        break;
                    }
                    
                    image.setY(image.getY()+10);
                  //  System.out.println(image.getX()+" "+image.getY());
                    break;
                case "l":
                    if(x<=10&&y<600&&y>460&&x>=0){
                        break;
                        
                    }
                    else if(x>=0&&x<=10&&y<450&&y>310){
                        break;
                    }
                    else if(x>=0&&x<=10&&y<300&&y>160){
                        break;
                    }
                    else if(x>=0&&x<=10&&y<150&&y>10){
                        break;
                    }
                    else if(x<=160&&y<600&&y>460&&x>=150){
                        break;
                        
                    }
                    else if(x>=150&&x<=160&&y<450&&y>310){
                        break;
                    }
                    else if(x>=150&&x<=160&&y<300&&y>160){
                        break;
                    }
                    else if(x<=160&&y<150&&y>10&&x>=150){
                        break;
                        
                    }
                    
                    else if(x>=300&&x<=310&&y<150&&y>10){
                        break;
                    }
                    else if(x<=310&&y<600&&y>460&&x>=300){
                        break;
                        
                    }
                    else if(x>=300&&x<=310&&y<450&&y>310){
                        break;
                    }
                    else if(x>=300&&x<=310&&y<300&&y>160){
                        break;
                    }
                    else if(x<=460&&y<600&&y>460&&x>=450){
                        break;
                        
                    }
                    else if(x>=450&&x<=460&&y<450&&y>310){
                        break;
                    }
                    else if(x>=450&&x<=460&&y<300&&y>160){
                        break;
                    }
                    else if(x>=450&&x<=460&&y<150&&y>10){
                        break;
                    }
                    else if(x<=610&&x>=600){
                        break;
                        
                    }
                    
                    image.setX(image.getX()+10);
                  //  System.out.println(image.getX()+" "+image.getY());
                    break;
                case "j":
                    if(x<=10&&x>=0){
                        break;
                        
                    }
                    
                    else if(x<=160&&y<600&&y>460&&x>=150){
                        break;
                        
                    }
                    else if(x>=150&&x<=160&&y<450&&y>310){
                        break;
                    }
                    else if(x>=150&&x<=160&&y<300&&y>160){
                        break;
                    }
                    else if(x<=160&&y<150&&y>10&&x>=150){
                        break;
                        
                    }
                    
                    else if(x>=300&&x<=310&&y<150&&y>10){
                        break;
                    }
                    else if(x<=310&&y<600&&y>460&&x>=300){
                        break;
                        
                    }
                    else if(x>=300&&x<=310&&y<450&&y>310){
                        break;
                    }
                    else if(x>=300&&x<=310&&y<300&&y>160){
                        break;
                    }
                    else if(x<=460&&y<600&&y>460&&x>=450){
                        break;
                        
                    }
                    else if(x>=450&&x<=460&&y<450&&y>310){
                        break;
                    }
                    else if(x>=450&&x<=460&&y<300&&y>160){
                        break;
                    }
                    else if(x>=450&&x<=460&&y<150&&y>10){
                        break;
                    }
                    else if(x<=610&&y<600&&y>460&&x>=600){
                        break;
                        
                    }
                    else if(x>=600&&x<=610&&y<450&&y>310){
                        break;
                    }
                    else if(x>=600&&x<=610&&y<300&&y>160){
                        break;
                    }
                    else if(x>=600&&x<=610&&y<150&&y>10){
                        break;
                    }
                    image.setX(image.getX()-10);
                //    System.out.println(image.getX()+" "+image.getY());
                    break;
                case "s":
                    if(is_bomb_set_first_bomb==0){
                     is_bomb_set_first_bomb=1;
                    iMage.setX(image.getX());//iMage for bomb picture,image for bomberman
                    iMage.setY(image.getY());
                    //root.getChildren().add(iMage);  
                    // if((NM.image.getX()>=40&&NM.iMage.getX()<=130&&NM.iMage.getY()>=0&&NM.iMage.getY()<=10)||(NM.iMage.getX()>=190&&NM.iMage.getX()<=270&&NM.iMage.getY()>=0&&NM.iMage.getY()<=10)||(NM.iMage.getX()>=340&&NM.iMage.getX()<=430&&NM.iMage.getY()>=0&&NM.iMage.getY()<=10)||(NM.iMage.getX()>=490&&NM.iMage.getX()<=580&&NM.iMage.getY()>=0&&NM.iMage.getY()<=10)||(NM.iMage.getX()>=40&&NM.iMage.getX()<=130&&NM.iMage.getY()>=150&&NM.iMage.getY()<=160)||(NM.iMage.getX()>=190&&NM.iMage.getX()<=270&&NM.iMage.getY()>=150&&NM.iMage.getY()<=160)||(NM.iMage.getX()>=340&&NM.iMage.getX()<=430&&NM.iMage.getY()>=150&&NM.iMage.getY()<=160)||(NM.iMage.getX()>=490&&NM.iMage.getX()<=580&&NM.iMage.getY()>=150&&NM.iMage.getY()<=160)||(NM.iMage.getX()>=40&&NM.iMage.getX()<=130&&NM.iMage.getY()>=300&&NM.iMage.getY()<=310)||(NM.iMage.getX()>=190&&NM.iMage.getX()<=270&&NM.iMage.getY()>=300&&NM.iMage.getY()<=310)||(NM.iMage.getX()>=340&&NM.iMage.getX()<=430&&NM.iMage.getY()>=300&&NM.iMage.getY()<=310)||(NM.image.getX()>=490&&NM.iMage.getX()<=580&&NM.iMage.getY()>=300&&NM.iMage.getY()<=310)||(NM.iMage.getX()>=40&&NM.iMage.getX()<=130&&NM.iMage.getY()>=450&&NM.iMage.getY()<=460)||(NM.iMage.getX()>=190&&NM.iMage.getX()<=270&&NM.iMage.getY()>=450&&NM.iMage.getY()<=460)||(NM.iMage.getX()>=340&&NM.iMage.getX()<=430&&NM.iMage.getY()>=450&&NM.iMage.getY()<=460)||(NM.iMage.getX()>=490&&NM.iMage.getX()<=580&&NM.iMage.getY()>=450&&NM.iMage.getY()<=460)||(NM.iMage.getX()>=40&&NM.iMage.getX()<=130&&NM.iMage.getY()>=600&&NM.iMage.getY()<=610)||(NM.iMage.getX()>=190&&NM.iMage.getX()<=270&&NM.iMage.getY()>=600&&NM.iMage.getY()<=610)||(NM.iMage.getX()>=340&&NM.iMage.getX()<=430&&NM.iMage.getY()>=600&&NM.iMage.getY()<=610)||(NM.iMage.getX()>=490&&NM.iMage.getX()<=580&&NM.iMage.getY()>=600&&NM.iMage.getY()<=610)){
                   
                    
                try {
                    Thread a=new Thread(new firstthread());
                    a.start();
                  
                    
                } catch (Exception ex) {
                    Logger.getLogger(NM2.class.getName()).log(Level.SEVERE, null, ex);
                }
                   
                  
                  
                             
                    }else if(is_bomb_set_second_bomb==0){
                         is_bomb_set_second_bomb=1;
                    iMage2.setX(image.getX());//iMage for bomb picture,image for bomberman
                    iMage2.setY(image.getY());
                    //root.getChildren().add(iMage);  
                    // if((NM.image.getX()>=40&&NM.iMage.getX()<=130&&NM.iMage.getY()>=0&&NM.iMage.getY()<=10)||(NM.iMage.getX()>=190&&NM.iMage.getX()<=270&&NM.iMage.getY()>=0&&NM.iMage.getY()<=10)||(NM.iMage.getX()>=340&&NM.iMage.getX()<=430&&NM.iMage.getY()>=0&&NM.iMage.getY()<=10)||(NM.iMage.getX()>=490&&NM.iMage.getX()<=580&&NM.iMage.getY()>=0&&NM.iMage.getY()<=10)||(NM.iMage.getX()>=40&&NM.iMage.getX()<=130&&NM.iMage.getY()>=150&&NM.iMage.getY()<=160)||(NM.iMage.getX()>=190&&NM.iMage.getX()<=270&&NM.iMage.getY()>=150&&NM.iMage.getY()<=160)||(NM.iMage.getX()>=340&&NM.iMage.getX()<=430&&NM.iMage.getY()>=150&&NM.iMage.getY()<=160)||(NM.iMage.getX()>=490&&NM.iMage.getX()<=580&&NM.iMage.getY()>=150&&NM.iMage.getY()<=160)||(NM.iMage.getX()>=40&&NM.iMage.getX()<=130&&NM.iMage.getY()>=300&&NM.iMage.getY()<=310)||(NM.iMage.getX()>=190&&NM.iMage.getX()<=270&&NM.iMage.getY()>=300&&NM.iMage.getY()<=310)||(NM.iMage.getX()>=340&&NM.iMage.getX()<=430&&NM.iMage.getY()>=300&&NM.iMage.getY()<=310)||(NM.image.getX()>=490&&NM.iMage.getX()<=580&&NM.iMage.getY()>=300&&NM.iMage.getY()<=310)||(NM.iMage.getX()>=40&&NM.iMage.getX()<=130&&NM.iMage.getY()>=450&&NM.iMage.getY()<=460)||(NM.iMage.getX()>=190&&NM.iMage.getX()<=270&&NM.iMage.getY()>=450&&NM.iMage.getY()<=460)||(NM.iMage.getX()>=340&&NM.iMage.getX()<=430&&NM.iMage.getY()>=450&&NM.iMage.getY()<=460)||(NM.iMage.getX()>=490&&NM.iMage.getX()<=580&&NM.iMage.getY()>=450&&NM.iMage.getY()<=460)||(NM.iMage.getX()>=40&&NM.iMage.getX()<=130&&NM.iMage.getY()>=600&&NM.iMage.getY()<=610)||(NM.iMage.getX()>=190&&NM.iMage.getX()<=270&&NM.iMage.getY()>=600&&NM.iMage.getY()<=610)||(NM.iMage.getX()>=340&&NM.iMage.getX()<=430&&NM.iMage.getY()>=600&&NM.iMage.getY()<=610)||(NM.iMage.getX()>=490&&NM.iMage.getX()<=580&&NM.iMage.getY()>=600&&NM.iMage.getY()<=610)){
                   
                    
                try {
                    Thread b=new Thread(new secondthread());
                    b.start();
                  
                    
                } catch (Exception ex) {
                    Logger.getLogger(NM2.class.getName()).log(Level.SEVERE, null, ex);
                }
                   
                    }else if(is_bomb_set_third_bomb==0){
                         is_bomb_set_third_bomb=1;
                    iMage3.setX(image.getX());//iMage for bomb picture,image for bomberman
                    iMage3.setY(image.getY());
                    //root.getChildren().add(iMage);  
                    // if((NM.image.getX()>=40&&NM.iMage.getX()<=130&&NM.iMage.getY()>=0&&NM.iMage.getY()<=10)||(NM.iMage.getX()>=190&&NM.iMage.getX()<=270&&NM.iMage.getY()>=0&&NM.iMage.getY()<=10)||(NM.iMage.getX()>=340&&NM.iMage.getX()<=430&&NM.iMage.getY()>=0&&NM.iMage.getY()<=10)||(NM.iMage.getX()>=490&&NM.iMage.getX()<=580&&NM.iMage.getY()>=0&&NM.iMage.getY()<=10)||(NM.iMage.getX()>=40&&NM.iMage.getX()<=130&&NM.iMage.getY()>=150&&NM.iMage.getY()<=160)||(NM.iMage.getX()>=190&&NM.iMage.getX()<=270&&NM.iMage.getY()>=150&&NM.iMage.getY()<=160)||(NM.iMage.getX()>=340&&NM.iMage.getX()<=430&&NM.iMage.getY()>=150&&NM.iMage.getY()<=160)||(NM.iMage.getX()>=490&&NM.iMage.getX()<=580&&NM.iMage.getY()>=150&&NM.iMage.getY()<=160)||(NM.iMage.getX()>=40&&NM.iMage.getX()<=130&&NM.iMage.getY()>=300&&NM.iMage.getY()<=310)||(NM.iMage.getX()>=190&&NM.iMage.getX()<=270&&NM.iMage.getY()>=300&&NM.iMage.getY()<=310)||(NM.iMage.getX()>=340&&NM.iMage.getX()<=430&&NM.iMage.getY()>=300&&NM.iMage.getY()<=310)||(NM.image.getX()>=490&&NM.iMage.getX()<=580&&NM.iMage.getY()>=300&&NM.iMage.getY()<=310)||(NM.iMage.getX()>=40&&NM.iMage.getX()<=130&&NM.iMage.getY()>=450&&NM.iMage.getY()<=460)||(NM.iMage.getX()>=190&&NM.iMage.getX()<=270&&NM.iMage.getY()>=450&&NM.iMage.getY()<=460)||(NM.iMage.getX()>=340&&NM.iMage.getX()<=430&&NM.iMage.getY()>=450&&NM.iMage.getY()<=460)||(NM.iMage.getX()>=490&&NM.iMage.getX()<=580&&NM.iMage.getY()>=450&&NM.iMage.getY()<=460)||(NM.iMage.getX()>=40&&NM.iMage.getX()<=130&&NM.iMage.getY()>=600&&NM.iMage.getY()<=610)||(NM.iMage.getX()>=190&&NM.iMage.getX()<=270&&NM.iMage.getY()>=600&&NM.iMage.getY()<=610)||(NM.iMage.getX()>=340&&NM.iMage.getX()<=430&&NM.iMage.getY()>=600&&NM.iMage.getY()<=610)||(NM.iMage.getX()>=490&&NM.iMage.getX()<=580&&NM.iMage.getY()>=600&&NM.iMage.getY()<=610)){
                   
                    
                try {
                    Thread c=new Thread(new thirdthread());
                    c.start();
                  
                    
                } catch (Exception ex) {
                    Logger.getLogger(NM2.class.getName()).log(Level.SEVERE, null, ex);
                }
                   
                    
                    }
                    else if(is_bomb_set_fourth_bomb==0){
                         is_bomb_set_fourth_bomb=1;
                    iMage4.setX(image.getX());//iMage for bomb picture,image for bomberman
                    iMage4.setY(image.getY());
                  
                    
                try {
                    Thread d=new Thread(new fourththread());
                    d.start();
                  
                    
                } catch (Exception ex) {
                    Logger.getLogger(NM2.class.getName()).log(Level.SEVERE, null, ex);
                }
                   
                    
                    }
            }
        });
         primaryStage.show();
      
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //   new Thread(new music_play_thread()).start();
        new ClientMain1();
        launch(args);
    }
  
        
    }
    
    


