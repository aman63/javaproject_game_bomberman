/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nm2;

import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import nm2.*;

/**
 *
 * @author User
 */
public class collidethread implements Runnable{
        final URL resource = getClass().getResource("Fire.wav");
    final Media media = new Media(resource.toString());
    final MediaPlayer mediaPlayer = new MediaPlayer(media);
    public collidethread(){
        new Thread(this).start();
    }
    @Override
    public void run() {
        if(NM2.number_of_lives_left==5){
             mediaPlayer.play();
            NM2.life5.setX(2000);
            NM2.life5.setX(2000);
            NM2.number_of_lives_left--;
            
        }else if(NM2.number_of_lives_left==4){
             mediaPlayer.play();
            NM2.life4.setX(2000);
            NM2.life4.setY(2000);
            NM2.number_of_lives_left--;
        }else if(NM2.number_of_lives_left==3){
             mediaPlayer.play();
            NM2.life3.setX(2000);
            NM2.life3.setY(2000);
            NM2.number_of_lives_left--;
        }else if(NM2.number_of_lives_left==2){
             mediaPlayer.play();
            NM2.life2.setX(2000);
            NM2.life2.setY(2000);
            NM2.number_of_lives_left--;
        }else if(NM2.number_of_lives_left==1){
             mediaPlayer.play();
            NM2.life1.setX(2000);
            NM2.life1.setY(2000);
            NM2.number_of_lives_left--;
            NM2.gameover.setX(0);
                 NM2.gameover.setY(0);
            try {
                Thread.sleep(300);
                System.exit(0);
            } catch (InterruptedException ex) {
                Logger.getLogger(collidethread.class.getName()).log(Level.SEVERE, null, ex);
            }
        }try{
            Thread.sleep(2000);
            Reader.flag=true;
            
        }catch(Exception e){
            
            
            System.out.println("got it");
        }
    }
    
}
