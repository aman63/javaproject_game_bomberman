/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nm2;

import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import nm2.*;

/**
 *
 * @author User
 */
public class lifeshow_forsecondplayer implements Runnable{
 final URL resource = getClass().getResource("Fire.wav");
    final Media media = new Media(resource.toString());
    final MediaPlayer mediaPlayer = new MediaPlayer(media);
    public lifeshow_forsecondplayer(){
        new Thread(this).start();
    }
    public void run() {
          if(NM2.secondplayer_number_of_lives_left==4){
            NM2.secondplayer_life5.setX(2000);
            NM2.secondplayer_life5.setX(2000);
             mediaPlayer.play();
            
            
        }else if(NM2.secondplayer_number_of_lives_left==3){
            NM2.secondplayer_life4.setX(2000);
            NM2.secondplayer_life4.setY(2000);
             mediaPlayer.play();
            
        }else if(NM2.secondplayer_number_of_lives_left==2){
            NM2.secondplayer_life3.setX(2000);
            NM2.secondplayer_life3.setY(2000);
             mediaPlayer.play();
            
        }else if(NM2.secondplayer_number_of_lives_left==1){
            NM2.secondplayer_life2.setX(2000);
            NM2.secondplayer_life2.setY(2000);
             mediaPlayer.play();
            
        }else if(NM2.secondplayer_number_of_lives_left==0){
            NM2.secondplayer_life1.setX(2000);
            NM2.secondplayer_life1.setY(2000);
             mediaPlayer.play();
             NM2.winner.setX(0);
             NM2.winner.setY(0);
              try {
                  Thread.sleep(300);
                  System.exit(0);
              } catch (InterruptedException ex) {
                  Logger.getLogger(lifeshow_forsecondplayer.class.getName()).log(Level.SEVERE, null, ex);
              }
             
            
        }try{
            NM2.prev_secondplayer_number_of_lives_left=NM2.secondplayer_number_of_lives_left;
            Thread.sleep(100);
        }catch(Exception e){
            
            
            System.out.println("got it");
        }
    }
    
}
