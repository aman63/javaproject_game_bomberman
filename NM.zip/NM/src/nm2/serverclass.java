/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nm2;

import myutil.data;
import java.net.ServerSocket;
import java.net.Socket;
import myutil.networkutil;

/**
 *
 * @author User
 */
public class serverclass implements Runnable{
    ServerSocket serversocket;
    public serverclass(){
        try{
            serversocket=new ServerSocket(44444);
        }catch(Exception e){
            System.out.println("can not create a server socket");
        }
      new Thread(this).start();
     
    }

   
    public void run() {
        Socket clientsocket=new Socket();
       
        try{
            clientsocket=serversocket.accept();
        }catch(Exception e){
            System.out.println("can not catch client client socket");
        }
        new workingthread(clientsocket);
        
    }
   
}
class workingthread implements Runnable{
   
    networkutil nc;
   workingthread(Socket clientsocket){
     
       nc=new networkutil(clientsocket);
       new Thread(this).start();
       
   }
    public void run() {
        double x,y;
        boolean flag=true;
        data d=new data();
       while(true){
            if(!flag) break;
            try{         
            d=(data)(nc.read());
            x=d.x;
            y=d.y;
            System.out.println(x);
          //  NM2.image2.setX(x);
         //   NM2.image2.setY(y);
            }catch(Exception e){
                System.out.println("connection lost");
                flag=false;
            }
        
    }
    }
}