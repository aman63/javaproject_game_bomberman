/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myutil;

import java.io.Serializable;

/**
 *
 * @author User
 */
public class data implements Serializable{
    public double x,y;
    public data(){
        
    }
    public data(double x,double y){
        this.x=x;
        this.y=y;
    }
}
