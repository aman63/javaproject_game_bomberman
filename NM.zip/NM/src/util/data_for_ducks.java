/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.io.Serializable;

/**
 *
 * @author User
 */
public class data_for_ducks implements Serializable{
     public double x,y,secondplayer_bomb1_x,secondplayer_bomb1_y,secondplayer_bomb2_x,secondplayer_bomb2_y, secondplayer_bomb3_x,secondplayer_bomb3_y,secondplayer_bomb4_x,secondplayer_bomb4_y,secondplayer_ullomboimage1_x,secondplayer_ullomboimage1_y,secondplayer_fireimage1_x,secondplayer_fireimage1_y,secondplayer_ullomboimage2_x,secondplayer_ullomboimage2_y,secondplayer_fireimage2_x,secondplayer_fireimage2_y;
    public double secondplayer_ullomboimage3_x,secondplayer_ullomboimage3_y,secondplayer_fireimage3_x,secondplayer_fireimage3_y;
    public double secondplayer_ullomboimage4_x,secondplayer_ullomboimage4_y,secondplayer_fireimage4_x,secondplayer_fireimage4_y;
   public int number_of_lives_for_secondplayer;
    public double d1x,d1y,d2x,d2y,d3x,d3y,d4x,d4y,d5x,d5y;
    public data_for_ducks(){
        
    }
    public data_for_ducks(double x,double y,double secondplayer_bomb1_x,double secondplayer_bomb1_y,double secondplayer_bomb2_x,double secondplayer_bomb2_y,double  secondplayer_bomb3_x,double secondplayer_bomb3_y,double secondplayer_bomb4_x,double secondplayer_bomb4_y,double secondplayer_ullomboimage1_x,double secondplayer_ullomboimage1_y,double secondplayer_fireimage1_x,double secondplayer_fireimage1_y,double secondplayer_ullomboimage2_x,double secondplayer_ullomboimage2_y,double secondplayer_fireimage2_x,double secondplayer_fireimage2_y,double secondplayer_ullomboimage3_x,double secondplayer_ullomboimage3_y,double secondplayer_fireimage3_x,double secondplayer_fireimage3_y,double secondplayer_ullomboimage4_x,double secondplayer_ullomboimage4_y,double secondplayer_fireimage4_x,double secondplayer_fireimage4_y,int number_of_lives_for_secondplayer,double d1x,double d1y,double d2x,double d2y,double d3x,double d3y,double d4x,double d4y,double d5x,double d5y){
          this.x=x;
        this.y=y;
        this.secondplayer_bomb1_x=secondplayer_bomb1_x;
        this.secondplayer_bomb1_y=secondplayer_bomb1_y;
        this.secondplayer_bomb2_x=secondplayer_bomb2_x;
        this.secondplayer_bomb2_y=secondplayer_bomb2_y;
         this.secondplayer_bomb3_x=secondplayer_bomb3_x;
        this.secondplayer_bomb3_y=secondplayer_bomb3_y;
          this.secondplayer_bomb4_x=secondplayer_bomb4_x;
        this.secondplayer_bomb4_y=secondplayer_bomb4_y;
        this.secondplayer_ullomboimage1_x=secondplayer_ullomboimage1_x;
        this.secondplayer_ullomboimage1_y=secondplayer_ullomboimage1_y;
        this.secondplayer_fireimage1_x=secondplayer_fireimage1_x;
        this.secondplayer_fireimage1_y=secondplayer_fireimage1_y;
          this.secondplayer_ullomboimage2_x=secondplayer_ullomboimage2_x;
        this.secondplayer_ullomboimage2_y=secondplayer_ullomboimage2_y;
        this.secondplayer_fireimage2_x=secondplayer_fireimage2_x;
        this.secondplayer_fireimage2_y=secondplayer_fireimage2_y;
          this.secondplayer_ullomboimage3_x=secondplayer_ullomboimage3_x;
        this.secondplayer_ullomboimage3_y=secondplayer_ullomboimage3_y;
        this.secondplayer_fireimage3_x=secondplayer_fireimage3_x;
        this.secondplayer_fireimage3_y=secondplayer_fireimage3_y;
          this.secondplayer_ullomboimage4_x=secondplayer_ullomboimage4_x;
        this.secondplayer_ullomboimage4_y=secondplayer_ullomboimage4_y;
        this.secondplayer_fireimage4_x=secondplayer_fireimage4_x;
        this.secondplayer_fireimage4_y=secondplayer_fireimage4_y;
        this.number_of_lives_for_secondplayer=number_of_lives_for_secondplayer;
        
        this.d1x=d1x;
        this.d1y=d1y;
        this.d2x=d2x;
        this.d2y=d2y;
        this.d3x=d3x;
        this.d3y=d3y;
          this.d4x=d4x;
        this.d4y=d4y;
          this.d5x=d5x;
        this.d5y=d5y;
    }
}
